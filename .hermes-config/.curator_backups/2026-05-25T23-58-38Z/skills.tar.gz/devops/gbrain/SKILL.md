---
name: gbrain
description: "Install, configure, and operate G-Brain (garrytan/gbrain) — a production-grade brain layer for Hermes with synthesis, graph traversal, gap analysis, and self-wiring knowledge graph."
version: 1.1.0
author: Hermes Agent
tags: [gbrain, brain-layer, knowledge-management, rag, synthesis, knowledge-graph]
related_skills: [hermes-maintenance, remote-agent-infrastructure]
---

# G-Brain

G-Brain is a brain layer for AI agents (OpenClaw/Hermes/Claude Code) that goes beyond simple RAG to provide synthesis, graph traversal, and gap analysis in a single system. Powers Garry Tan's personal autonomous agents.

**Key differentiator:** `gbrain search` returns ranked pages; `gbrain think` returns a synthesized answer with explicit citations AND a gap analysis (stale data, missing context, contradictions).

## When to Use

- User asks to install or set up G-Brain
- User needs to configure a knowledge brain for Hermes
- User mentions "brain layer", "gbrain", or Garry Tan's knowledge system
- User wants persistent, searchable knowledge across sessions beyond simple RAG
- User has large reference material collections (textbooks, regulations, research papers) that need cross-source synthesis

## Prerequisites

- **Bun** (v1.0+) — installed at `~/.bun/bin/bun` or system-wide
- **One API key for embeddings** — see provider table below
- PGLite (zero-config, default) — no server needed; Postgres/Supabase optional for scale

## Installation

### DO NOT use `bun install -g`

**The Bun global install is broken.** Bun blocks the top-level postinstall hook on global installs, so schema migrations never run and the CLI aborts with `Aborted()` when it opens PGLite. Tracking issue: [#218](https://github.com/garrytan/gbrain/issues/218).

### Correct install path (git clone + bun link)

```bash
git clone https://github.com/garrytan/gbrain.git ~/gbrain && cd ~/gbrain

# Ensure bun is in PATH
export PATH="$HOME/.bun/bin:$PATH"

bun install && bun link

# Verify
gbrain --version   # Should print e.g. 0.41.10.1
```

### Alternative: if bun install -g was used

Run recovery:
```bash
gbrain apply-migrations --yes
```

If that fails, fall back to the git clone path.

## API Key Setup

G-Brain auto-detects embedding providers from environment variables on `gbrain init`. Source the key into the environment before running `gbrain init` — the CLI reads from env vars, not from `~/.gbrain/config.json`.

### Embedding Provider Options (sorted by cost)

| Provider | Env Var | Default Dims | Cost/1M tokens | Notes |
|----------|---------|-------------|----------------|-------|
| **NVIDIA Nemotron (via OpenRouter)** | `OPENROUTER_API_KEY` | 1024 (supports 512/768/1024/1536) | **$0 (FREE)** | Best for OpenRouter users with credit issues; 131K context, multimodal |
| `openrouter` (OpenAI/text-embedding-3-small) | `OPENROUTER_API_KEY` | 1536 | $0.02 | Default OR embedding; may hit "Insufficient credits" on some OR accounts |
| `google` | `GOOGLE_GENERATIVE_AI_API_KEY` | 768 | $0.025 | Gemini embeddings; also works via OpenRouter as `openrouter:google/gemini-embedding-2-preview` |
| `zeroentropyai` | `ZEROENTROPY_API_KEY` | 2560 (Matryoshka to 1280/640/320/...) | $0.05 | Fast + cheap; also serves as reranker |
| `openai` | `OPENAI_API_KEY` | 1536 | $0.13 | Most battle-tested for vector search |
| `voyage` | `VOYAGE_API_KEY` | 1024 | $0.18 | Best quality per dollar; code-tuned variant available |
| `ollama` | (none — local) | 768 | $0 | Local only, requires Ollama daemon running |
| `llama-server` | (none — local) | user-set | $0 | Local only, requires llama-server daemon |

**Important:** OpenRouter may return "Insufficient credits" for many embedding models (`openai/text-embedding-3-small`, `bge-m3`, `qwen/qwen3-embedding-8b`) even when the account has credit balance. This is an OpenRouter routing/provider-availability issue, not an actual balance problem. The **NVIDIA Nemotron** model (`nvidia/llama-nemotron-embed-vl-1b-v2`) consistently works on OR and is **free**.

### Using OpenRouter (recommended with Hermes if OpenRouter key exists)

```bash
export OPENROUTER_API_KEY=*** Verify the key works
gbrain providers test --model openrouter:openai/text-embedding-3-small
```

### Using BWS (Bitwarden Secrets Manager)

If keys are managed via BWS and the Hermes `.env` is populated at startup, source it:
```bash
set -a; source /root/.hermes/.env 2>/dev/null; set +a
```

## Search Mode Decision (CRITICAL — Ask the User)

**Before running `gbrain init`, you MUST present the cost matrix and confirm the user's choice.** The cost spread between corners is 25×. Silent acceptance is the wrong default.

Per-query cost at 10K queries/month (typical single-user volume):

| Mode | Budget | Haiku-tier | Sonnet-tier | Opus-tier | Characteristics |
|------|--------|-----------|-------------|-----------|-----------------|
| conservative | 4K, 10 chunks | ~$40/mo | ~$120/mo | ~$200/mo | No LLM expansion. Best for cost-sensitive, high-volume loops |
| balanced | 12K, 25 chunks | ~$100/mo | ~$300/mo | ~$500/mo | No expansion. Sonnet-tier sweet spot |
| tokenmax | No budget, 50 chunks | ~$200/mo | ~$600/mo | ~$1,000/mo | LLM expansion ON. Best for frontier models |

Scales linearly: ×10 for 100K/mo, ÷10 for 1K/mo.

Set after user picks:
```bash
gbrain config set search.mode <mode>
```

For a 20-chunk limit matching pre-v0.32.x shape:
```bash
gbrain config set search.searchLimit 20
```

Verify: `gbrain search modes`

## Provider Health Testing

Before initializing, test that your chosen embedding model works:

```bash
# Test a specific model (before init — doesn't need a brain)
gbrain providers test --model openrouter:nvidia/llama-nemotron-embed-vl-1b-v2

# Test with chat completion model
gbrain providers test --model openrouter:meta-llama/llama-3.1-8b-instruct

# List all available providers
gbrain providers list
```

## Brain Initialization

After search mode is confirmed:

```bash
# For a brain with API key set — auto-detects provider
gbrain init --pglite          # Default PGLite, zero-config, no server needed

# Use a specific embedding model with explicit dimensions
OPENROUTER_API_KEY=*** gbrain init --pglite \
  --embedding-model openrouter:nvidia/llama-nemotron-embed-vl-1b-v2 \
  --embedding-dimensions 1024

# To skip embedding (keyword-only search)
gbrain init --pglite --no-embedding
```

To use a non-default provider, pass `--model`:
```bash
gbrain init --pglite --model openrouter
```

To use a non-default chat model after init:
```bash
# Reasonable cheap model for synthesis
gbrain config set chat_model openrouter:meta-llama/llama-3.1-8b-instruct

# Absolute cheapest ($0.01/M input)
gbrain config set chat_model openrouter:inclusionai/ling-2.6-flash
```

Verify:
```bash
gbrain doctor --json    # Full health check
```

`gbrain init` creates `~/.gbrain/config.json` with the resolved provider + dimensions.

## Brain Repo Setup

The brain's markdown files live in a SEPARATE git repo, NOT inside `~/gbrain/`:

```bash
mkdir -p ~/brain && cd ~/brain && git init
```

Set up a MECE directory structure inside the brain repo. Read the recommended schema for guidance:
```bash
# Read the schema guide (in the gbrain repo)
cat ~/gbrain/docs/GBRAIN_RECOMMENDED_SCHEMA.md
```

Typical structure:
```
~/brain/
├── people/
├── companies/
├── concepts/
├── projects/
├── notes/
└── daily/
```

## Importing Knowledge

### Standard Import

```bash
# Import markdown files from the brain repo
gbrain import ~/brain/

# Generate vector embeddings (if --no-embed was used)
gbrain embed --stale

# Test a query
gbrain query "key themes across these documents?"
```

### Importing Extracted Reference Materials (.txt → .md)

When working with extracted textbook chapters, regulations, or other reference content that exists as `.txt` files:

1. **Create a clean copy as `.md` files** — skip `.hms-bak` backups:
   ```bash
   DEST=~/brain/extracted
   mkdir -p $DEST/<category>
   for src in /path/to/*.txt; do
     [[ "$src" == *.hms-bak ]] && continue
     base=$(basename "$src" .txt)
     cp "$src" "$DEST/<category>/$base.md"
   done
   ```

2. **Import with sufficient timeout** — large collections (100+ files, 50MB+) may exceed the default 180s. Use `gbrain import` with a longer timeout or run in multiple passes. GBrain skips already-imported files on re-run.

3. **Large file warnings are informational** — files >50KB trigger content-sanity warnings but still import. Very large files (>1MB) may be soft-blocked from embedding (page lands, embedding skipped) — the full text is searchable via FTS5 but won't appear in vector search results. Split oversized files if vector search coverage is needed.

4. **Verify import counts:**
   ```bash
   gbrain stats
   # Pages: N  Chunks: N  Embedded: N
   ```

### Knowledge Graph Setup

Backfill typed-link graph and timeline for existing brains:

```bash
gbrain extract links --source db --dry-run | head -20   # preview
gbrain extract links --source db                          # commit
gbrain extract timeline --source db                       # dated events
gbrain stats                                              # verify links > 0
```

For large brains (>10K pages), use `--since YYYY-MM-DD` for incremental extraction. The process is idempotent.

## Verification

```bash
gbrain doctor --json    # Full health check
gbrain models           # Which AI models are configured for what
gbrain models doctor    # 1-token probe per configured model
gbrain search "test query"  # Quick smoke test
```

## Community Manifest Tracking

When installed, add to `~/.hermes/community-manifest.json`:

```json
{
  "name": "gbrain",
  "type": "external_tool",
  "source": "https://github.com/garrytan/gbrain",
  "install_date": "<YYYY-MM-DD>",
  "version": "<from 'gbrain --version'>",
  "install_method": "git clone → bun install → bun link",
  "update_command": "cd ~/gbrain && git pull && bun install && bun link",
  "post_update": "gbrain apply-migrations --yes --non-interactive (if needed)",
  "status": "active"
}
```

## Related

- `devops/hermes-maintenance` — community manifest governance, long-term Hermes care
- `devops/gbrain/references/session-install-transcript.md` — detailed session-specific install transcript with error resolution
- `devops/gbrain/references/openrouter-embedding-models.md` — OpenRouter embedding model quirks, dimension passthrough bug fix, and working model list
- `devops/remote-agent-infrastructure` — Tailscale mesh, git as memory layer, scripting discipline (complementary infra)
- Garry's MCP conversation skillpack: `gbrain skillpack list`

## Pitfalls

- **Bun global install bug (#218):** Do NOT use `bun install -g github:garrytan/gbrain`. Always clone + bun link.
- **Search mode default:** `gbrain init` auto-applies `tokenmax` unless a Haiku-tier agent or no OpenAI key is detected. Always confirm with the user.
- **Non-TTY init without API key:** Falls immediately. Must set at least one embedding provider env var, pass `--no-embedding`, or run interactively.
- **PGLite cannot ALTER COLUMN vector(N):** Switching embedding models requires `gbrain reinit-pglite` (wipes embeddings, re-indexes). No in-place column type change.
- **Memory-constrained environments:** PGLite runs as WASM inside the Bun process. On <1GB RAM VPS, consider Supabase + pgvector instead.
- **API key in env vs config:** `gbrain init` reads from env vars but writes the resolved provider/dims to `~/.gbrain/config.json`. Keys themselves are NOT stored in config — they're read from env at runtime.
- **Brain repo ≠ tool repo:** The user's markdown knowledge (`~/brain/`) is a separate git repo from the gbrain tool install (`~/gbrain/`). Do not conflate them.
- **Known bug: dimension passthrough for unknown openai-compatible models (v0.41.10.1):** `dimsProviderOptions()` in `src/core/ai/dims.ts` returns `undefined` for any embedding model in the `openai-compatible` tier that isn't in its switch cases (ZeroEntropy, Voyage, text-embedding-3, DashScope, Zhipu, MiniMax). Models like `nvidia/llama-nemotron-embed-vl-1b-v2` on OpenRouter never receive the `dimensions` parameter, returning native 2048-dim instead of configured dims. **Fix:** Replace `return undefined;` at the end of the `openai-compatible` case with `return { openaiCompatible: { dimensions: dims } };`. Safe because endpoints that don't support `dimensions` silently ignore the field per OpenAI-compat spec.
- **OpenRouter embedding model routing:** Models like `openai/text-embedding-3-small`, `bge-m3`, `qwen/qwen3-embedding-8b` may return "Insufficient credits" on OpenRouter even with valid balance. This is a routing issue, not a key problem. Use `nvidia/llama-nemotron-embed-vl-1b-v2` (free, confirmed working) instead.
- **Chat model selection:** GBrain defaults chat to `openrouter:openai/gpt-5.2`. For a cheap alternative that still handles synthesis well, use `openrouter:meta-llama/llama-3.1-8b-instruct` ($0.02/M input). Cheapest option overall: `inclusionai/ling-2.6-flash` ($0.01/M input).
- **Large imports may timeout:** Importing 100+ files (50MB+) can exceed the default 180s terminal timeout. Run with `timeout=300` or in multiple passes — GBrain skips already-imported files on re-run.
- **HMS sync after GBrain operations:** If files were created/deleted on the VPS during GBrain setup (like `.hms-bak` debris or extracted reference copies), ensure the same changes are reflected locally before the next `hms push`. HMS uses `--update` (no `--delete`), so files that exist locally but were deleted on VPS get re-uploaded. Run `hms push --dry-run` first to check, then clean up local copies.
