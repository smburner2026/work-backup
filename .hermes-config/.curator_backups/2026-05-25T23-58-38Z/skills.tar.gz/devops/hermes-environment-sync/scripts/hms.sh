#!/usr/bin/env bash
# hms — Hermes Multi-Sync v1.0
# Single command to sync Hermes state between local (WSL) and VPS.
#
# Usage:
#   hms push      Local → VPS (run after finishing local work)
#   hms pull      VPS → Local (run before starting local work)
#   hms auto      Skills + files only, for cron (no gateway downtime)
#   hms status    Show what's out of sync
#
# Config via env vars:
#   HMS_VPS_HOST     SSH host (default: hetzner)
#   HMS_VPS_HERMES   ~/.hermes path on VPS (default: /root/.hermes)

set -euo pipefail

###############################################################################
# CONFIG
###############################################################################
VPS_HOST="${HMS_VPS_HOST:-hetzner}"
VPS_HERMES="${HMS_VPS_HERMES:-/root/.hermes}"
HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
TIMESTAMP=$(date +%Y-%m-%d_%H:%M:%S)

VPS_HERMES_BIN="/usr/local/lib/hermes-agent/venv/bin/hermes"
RSYNC_BASE="-avz --no-o --no-g --no-t"

###############################################################################
# Helpers
###############################################################################
info()  { echo "  [$(date +%H:%M:%S)] $*"; }
die()   { echo "  ERROR: $*" >&2; exit 1; }

check_ssh() {
  ssh -q -o ConnectTimeout=5 "$VPS_HOST" exit 2>/dev/null \
    || die "Cannot reach $VPS_HOST — check SSH config and VPN"
}

snapshot_db() {
  local src="$1" dst="$2"
  [ -f "$src" ] || { info "[db] $src not found, skipping"; return 0; }
  sqlite3 "$src" "VACUUM INTO '$dst';" || die "Failed to snapshot $src"
  info "[db] snapshot created: $dst ($(stat -c%s "$dst" 2>/dev/null || echo "?") bytes)"
}

vps_gateway_stop() {
  info "[gateway] stopping VPS Hermes..."
  ssh "$VPS_HOST" "XDG_RUNTIME_DIR=/run/user/\$(id -u) systemctl --user stop hermes-gateway.service 2>/dev/null" \
    || info "[gateway] stop command issued"
  sleep 1
}

vps_gateway_start() {
  info "[gateway] starting VPS Hermes..."
  ssh "$VPS_HOST" "XDG_RUNTIME_DIR=/run/user/\$(id -u) systemctl --user start hermes-gateway.service 2>/dev/null" \
    || info "[gateway] start command issued"
  sleep 2
  local status
  status=$(ssh "$VPS_HOST" "XDG_RUNTIME_DIR=/run/user/\$(id -u) systemctl --user is-active hermes-gateway.service 2>/dev/null" || echo "unknown")
  info "[gateway] status: $status"
}

sync_to_vps() {
  local src="$1" dst="$2" label="$3" exclude="${4:-}"
  ssh "$VPS_HOST" "mkdir -p \"$dst\"" 2>/dev/null || true
  local cmd="rsync $RSYNC_BASE"
  [ -n "$exclude" ] && cmd="$cmd --exclude='$exclude'"
  cmd="$cmd \"$src/\" \"$VPS_HOST:$dst/\""
  eval "$cmd" 2>&1 | tail -1 || true
  info "[$label] done"
}

sync_from_vps() {
  local src="$1" dst="$2" label="$3" exclude="${4:-}"
  mkdir -p "$dst"
  local cmd="rsync $RSYNC_BASE"
  [ -n "$exclude" ] && cmd="$cmd --exclude='$exclude'"
  cmd="$cmd \"$VPS_HOST:$src/\" \"$dst/\""
  eval "$cmd" 2>&1 | tail -1 || true
  info "[$label] done"
}

###############################################################################
# Commands
###############################################################################
cmd_push() {
  echo "=== HMS PUSH — Local → VPS ==="
  echo "  Time: $TIMESTAMP"
  echo "  VPS:  $VPS_HOST"
  echo ""
  check_ssh

  info "[skills] syncing to VPS..."
  sync_to_vps "$HERMES_HOME/skills" "$VPS_HERMES/skills" "skills"

  info "[files] syncing work directories..."
  rsync $RSYNC_BASE --delete \
    --exclude='.git/' --exclude='node_modules/' --exclude='venv/' --exclude='.venv/' \
    --exclude='__pycache__/' --exclude='*.pyc' --exclude='.DS_Store' \
    "$HOME/work/" "$VPS_HOST:~/work/" 2>&1 | tail -1 || true
  info "[files] work files synced"

  echo ""
  info "[db] preparing session database sync..."
  vps_gateway_stop

  snapshot_db "$HERMES_HOME/lcm.db" "/tmp/hms-lcm-snapshot.db"
  if [ -f /tmp/hms-lcm-snapshot.db ]; then
    info "[db] transferring session DB to VPS..."
    rsync -avz /tmp/hms-lcm-snapshot.db "$VPS_HOST:$VPS_HERMES/lcm.db" | tail -1
    ssh "$VPS_HOST" "rm -f $VPS_HERMES/lcm.db-wal $VPS_HERMES/lcm.db-shm" || true
    rm -f /tmp/hms-lcm-snapshot.db
    info "[db] session DB synced"
  fi

  if [ -d "$HERMES_HOME/mnemosyne" ]; then
    info "[memory] syncing Mnemosyne..."
    rsync $RSYNC_BASE --delete \
      --exclude='models/' --exclude='logs/' --exclude='.cache/' \
      "$HERMES_HOME/mnemosyne/" "$VPS_HOST:$VPS_HERMES/mnemosyne/" 2>&1 | tail -1 || true
    info "[memory] Mnemosyne synced"
  fi

  if [ -d "$HERMES_HOME/memories" ]; then
    info "[memories] syncing legacy memory files..."
    sync_to_vps "$HERMES_HOME/memories" "$VPS_HERMES/memories" "memories"
  fi

  if [ -d "$HERMES_HOME/profiles" ]; then
    info "[profiles] syncing profiles..."
    rsync $RSYNC_BASE --delete \
      --exclude='.env' --exclude='auth.json' --exclude='*.lock' \
      "$HERMES_HOME/profiles/" "$VPS_HOST:$VPS_HERMES/profiles/" 2>&1 | tail -1 || true
    info "[profiles] synced"
  fi

  info "[config] syncing config (excluding secrets)..."
  rsync $RSYNC_BASE \
    "$HERMES_HOME/config.yaml" "$VPS_HOST:$VPS_HERMES/config.yaml" 2>&1 | tail -1 || true

  echo ""
  vps_gateway_start

  echo ""
  echo "=== HMS PUSH complete ==="
}

cmd_pull() {
  echo "=== HMS PULL — VPS → Local ==="
  echo "  Time: $TIMESTAMP"
  echo "  VPS:  $VPS_HOST"
  echo ""
  check_ssh

  info "[skills] pulling from VPS..."
  sync_from_vps "$VPS_HERMES/skills" "$HERMES_HOME/skills" "skills"

  info "[files] pulling work directories..."
  rsync $RSYNC_BASE --delete \
    --exclude='.git/' --exclude='node_modules/' --exclude='venv/' --exclude='.venv/' \
    --exclude='__pycache__/' --exclude='*.pyc' --exclude='.DS_Store' \
    "$VPS_HOST:~/work/" "$HOME/work/" 2>&1 | tail -1 || true
  info "[files] work files pulled"

  info "[db] snapshotting VPS session database..."
  ssh "$VPS_HOST" "sqlite3 $VPS_HERMES/lcm.db \"VACUUM INTO '/tmp/hms-lcm-snapshot.db';\"" \
    || die "Failed to snapshot VPS session DB"
  info "[db] pulling session DB..."
  rsync -avz "$VPS_HOST:/tmp/hms-lcm-snapshot.db" "$HERMES_HOME/lcm.db" | tail -1
  ssh "$VPS_HOST" "rm -f /tmp/hms-lcm-snapshot.db" || true
  rm -f "$HERMES_HOME/lcm.db-wal" "$HERMES_HOME/lcm.db-shm" || true
  info "[db] session DB pulled"

  if ssh "$VPS_HOST" "[ -d $VPS_HERMES/mnemosyne ]"; then
    info "[memory] pulling Mnemosyne..."
    rsync $RSYNC_BASE --delete \
      --exclude='models/' --exclude='logs/' \
      "$VPS_HOST:$VPS_HERMES/mnemosyne/" "$HERMES_HOME/mnemosyne/" 2>&1 | tail -1 || true
    info "[memory] Mnemosyne pulled"
  fi

  if ssh "$VPS_HOST" "[ -d $VPS_HERMES/memories ]"; then
    info "[memories] pulling legacy memory files..."
    sync_from_vps "$VPS_HERMES/memories" "$HERMES_HOME/memories" "memories"
  fi

  if ssh "$VPS_HOST" "[ -d $VPS_HERMES/profiles ]"; then
    info "[profiles] pulling profiles..."
    rsync $RSYNC_BASE --delete \
      --exclude='.env' --exclude='auth.json' --exclude='*.lock' \
      "$VPS_HOST:$VPS_HERMES/profiles/" "$HERMES_HOME/profiles/" 2>&1 | tail -1 || true
    info "[profiles] pulled"
  fi

  info "[config] pulling config..."
  rsync $RSYNC_BASE "$VPS_HOST:$VPS_HERMES/config.yaml" "$HERMES_HOME/config.yaml" 2>&1 | tail -1 || true

  echo ""
  echo "=== HMS PULL complete ==="
  echo "  → Local Hermes now has latest VPS state"
}

cmd_auto() {
  echo "=== HMS AUTO — $TIMESTAMP ==="
  check_ssh

  info "[skills] pulling VPS updates..."
  rsync $RSYNC_BASE --update "$VPS_HOST:$VPS_HERMES/skills/" "$HERMES_HOME/skills/" 2>&1 | tail -1 || true
  info "[skills] pushing local updates..."
  rsync $RSYNC_BASE --update "$HERMES_HOME/skills/" "$VPS_HOST:$VPS_HERMES/skills/" 2>&1 | tail -1 || true

  info "[files] pulling VPS work files..."
  rsync $RSYNC_BASE --update --exclude='.git/' --exclude='node_modules/' "$VPS_HOST:~/work/" "$HOME/work/" 2>&1 | tail -1 || true
  info "[files] pushing local work files..."
  rsync $RSYNC_BASE --update --exclude='.git/' --exclude='node_modules/' "$HOME/work/" "$VPS_HOST:~/work/" 2>&1 | tail -1 || true

  echo "=== HMS AUTO complete ==="
}

cmd_status() {
  echo "=== HMS STATUS — $TIMESTAMP ==="
  check_ssh

  echo ""
  echo "── Skills ──"
  local vps_count
  vps_count=$(ssh "$VPS_HOST" "find $VPS_HERMES/skills -type f -name '*.md' | wc -l" 2>/dev/null || echo "?")
  local local_count
  local_count=$(find "$HERMES_HOME/skills" -type f -name '*.md' 2>/dev/null | wc -l || echo "?")
  echo "  VPS:   $vps_count skills"
  echo "  Local: $local_count skills"
  rsync $RSYNC_BASE --dry-run "$HERMES_HOME/skills/" "$VPS_HOST:$VPS_HERMES/skills/" 2>/dev/null \
    | grep -v '^building\|^sent\|^total\|\.d\.\.\.\.\.\.\.$\|^$' \
    | head -10 || echo "  (in sync)"

  echo ""
  echo "── Session Database ──"
  local vps_db=$(ssh "$VPS_HOST" "stat -c%s $VPS_HERMES/lcm.db 2>/dev/null || echo 0")
  local local_db=$(stat -c%s "$HERMES_HOME/lcm.db" 2>/dev/null || echo 0)
  echo "  VPS:   $(numfmt --to=iec $vps_db 2>/dev/null || echo "$vps_db bytes")"
  echo "  Local: $(numfmt --to=iec $local_db 2>/dev/null || echo "$local_db bytes")"
  if [ "$vps_db" != "$local_db" ] && [ "$vps_db" != "0" ] && [ "$local_db" != "0" ]; then
    echo "  ⚠  Sizes differ — run 'hms push' or 'hms pull' to sync"
  fi

  echo ""
  echo "── Work Files (local extra) ──"
  rsync $RSYNC_BASE --dry-run "$HOME/work/" "$VPS_HOST:~/work/" 2>/dev/null \
    | grep -v '^building\|^sent\|^total\|\.d\.\.\.\.\.\.\.$\|^$' \
    | head -10 || echo "  (in sync)"
  echo ""
  echo "── Work Files (VPS extra) ──"
  rsync $RSYNC_BASE --dry-run "$VPS_HOST:~/work/" "$HOME/work/" 2>/dev/null \
    | grep -v '^building\|^sent\|^total\|\.d\.\.\.\.\.\.\.$\|^$' \
    | head -10 || echo "  (in sync)"

  echo ""
  echo "── VPS Gateway ──"
  ssh "$VPS_HOST" "XDG_RUNTIME_DIR=/run/user/\$(id -u) systemctl --user is-active hermes-gateway.service 2>/dev/null" \
    || echo "  (not running)"

  echo ""
  echo "=== HMS STATUS done ==="
}

###############################################################################
# Main
###############################################################################
mkdir -p "$HOME/work" 2>/dev/null || true

case "${1:-help}" in
  push|up)      cmd_push ;;
  pull|down)    cmd_pull ;;
  auto)         cmd_auto ;;
  status|st)    cmd_status ;;
  *)
    echo "hms — Hermes Multi-Sync v1.0"
    echo ""
    echo "Usage:  hms COMMAND"
    echo ""
    echo "Commands:"
    echo "  push          Sync Local → VPS (end of local session)"
    echo "  pull          Sync VPS → Local (start of local session)"
    echo "  auto          Skills + files only, for cron (no DB, no downtime)"
    echo "  status        Show sync differences"
    echo ""
    echo "Config:"
    echo "  export HMS_VPS_HOST=hetzner     SSH host (default: hetzner)"
    echo "  export HMS_VPS_HERMES=/root/.hermes   VPS path (default: same)"
    ;;
esac
