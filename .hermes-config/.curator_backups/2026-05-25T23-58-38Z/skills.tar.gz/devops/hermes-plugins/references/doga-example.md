# DOGA Plugin — Example Community Plugin

Source: https://github.com/0z1-ghb/doga-hermes
Installed: 2026-05-24

## Structure

```
~/.hermes/plugins/doga/
├── plugin.yaml              # Manifest: hooks + doga toolset + doga command
├── __init__.py              # register(ctx) — hooks, tools, slash command
├── de_bono_hats.py          # Six Thinking Hats definitions by depth
├── depth_selector.py        # Auto depth assessment (low/med/high)
├── simulation_engine.py     # Monte Carlo engine (AST-whitelisted)
├── thinking_prompt.py       # Prompt injection templates
└── output_formatter.py      # Response formatting
```

## plugin.yaml

```yaml
name: doga
version: "1.1.0"
description: "Probabilistic, goal-aware thinking layer for Hermes Agent"
author: "0z1-ghb"
license: MIT
homepage: "https://github.com/0z1-ghb/doga-hermes"
hooks:
  - pre_llm_call
  - transform_llm_output
  - post_tool_call
toolsets:
  - doga
commands:
  - doga
```

## register(ctx) Pattern

```python
def register(ctx) -> None:
    ctx.register_hook("pre_llm_call", _on_pre_llm_call)
    ctx.register_hook("transform_llm_output", _on_transform_llm_output)
    ctx.register_hook("post_tool_call", _on_post_tool_call)

    ctx.register_tool(
        name="simulate",
        toolset="doga",
        schema=_SIMULATE_SCHEMA,
        handler=_simulate_tool_handler,
        check_fn=_check_simulate_requirements,
        description="Run Monte Carlo simulations over scenarios.",
        emoji="🎲",
    )
    ctx.register_tool(
        name="reason_deeper",
        toolset="doga",
        schema=_REASON_DEEPER_SCHEMA,
        handler=_reason_deeper_handler,
        check_fn=_check_reason_deeper_requirements,
        description="Recursively deepen reasoning via self-critique.",
        emoji="🔄",
    )
    ctx.register_command(
        "doga",
        handler=_handle_doga,
        description="Control DOGA probabilistic thinking.",
        args_hint="on|off|status|auto|manual|depth|hats|memory|...",
    )
```

## Update Command

```bash
cd /tmp && git clone https://github.com/0z1-ghb/doga-hermes.git --depth 1 && cp doga-hermes/doga/*.py ~/.hermes/plugins/doga/ && cp doga-hermes/plugin.yaml ~/.hermes/plugins/doga/ && rm -rf /tmp/doga-hermes
```
Then `hermes plugins enable doga` (if needed) + `/reset`.

## Slash Commands

| Command | Effect |
|---------|--------|
| `/doga on/off` | Toggle |
| `/doga status` | Show current settings |
| `/doga auto` | Auto depth (default) |
| `/doga manual low|medium|high` | Force level |
| `/doga depth <1-5>` | Set depth (manual mode) |
| `/doga hats on/off` | Toggle De Bono |
| `/doga show/hide` | Simulation panel |
| `/doga memory on/off` | Mnemosyne goal memory |
| `/doga max_recursion <1-5>` | Reason deeper limit |

## Dependencies

- Zero required (pure stdlib Python)
- Optional: `mnemosyne-memory` (pip) for goal memory persistence
