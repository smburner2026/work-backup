---
name: hermes-plugins
description: "Install, enable, update, and track community/third-party Hermes plugins — plugins not shipped with base Hermes."
version: 1.0.0
author: agent
tags: [hermes, plugins, community, devops]
---

# Hermes Plugins — Community Plugin Management

Covers the lifecycle of third-party Hermes plugins that don't ship with the base install. Bundled plugins (shipped via `hermes update`) are handled separately.

## How Hermes Plugin System Works

Each plugin is a directory under one of:
- `<repo>/plugins/<name>/` — bundled (shipped with Hermes)
- `~/.hermes/plugins/<name>/` — user-installed
- `./.hermes/plugins/<name>/` — project-local (opt-in via `HERMES_ENABLE_PROJECT_PLUGINS`)

Each directory must contain:
1. **`plugin.yaml`** — manifest declaring hooks, toolsets, and commands
2. **`__init__.py`** — with a `register(ctx)` function

### `plugin.yaml` Structure

```yaml
name: my-plugin
version: "1.0.0"
description: "What it does"
author: "name"
license: MIT
homepage: "https://github.com/..."
hooks:          # Optional — lifecycle hooks the plugin registers
  - pre_llm_call
  - transform_llm_output
  - post_tool_call
toolsets:       # Optional — toolset names the plugin provides
  - my-toolset
commands:       # Optional — slash commands the plugin registers
  - my-command
```

### `register(ctx)` Function

The `__init__.py` must expose a top-level `register(ctx)` function that receives a `PluginContext` object with these methods:

```python
def register(ctx) -> None:
    # Register lifecycle hooks
    ctx.register_hook("pre_llm_call", my_pre_call_handler)
    ctx.register_hook("transform_llm_output", my_output_handler)
    ctx.register_hook("post_tool_call", my_post_tool_handler)

    # Register tools (appear in model's tool schema)
    ctx.register_tool(
        name="my_tool",
        toolset="my-toolset",
        schema={...},          # OpenAI function-calling schema
        handler=my_handler,    # Callable
        check_fn=my_check,     # Returns bool — tool availability gate
        description="...",
        emoji="🔧",
    )

    # Register slash commands
    ctx.register_command(
        "my-command",
        handler=my_command_handler,
        description="...",
        args_hint="...",
    )
```

## Installing a Community Plugin

### From a GitHub Repo

```bash
# 1. Clone the repo
cd /tmp
git clone https://github.com/user/repo.git --depth 1

# 2. Copy plugin files to ~/.hermes/plugins/<name>/
mkdir -p ~/.hermes/plugins/<name>/
cp repo/<plugin-dir>/*.py ~/.hermes/plugins/<name>/
cp repo/plugin.yaml ~/.hermes/plugins/<name>/

# 3. Enable via Hermes
hermes plugins enable <name>

# 4. Verify it's active
hermes plugins list | grep <name>
# → should show "enabled"

# 5. Clean up temp clone
rm -rf /tmp/repo
```

### Post-Install

- Plugin takes effect on **next session** (`/reset` or fresh `hermes` invocation).
- If the plugin registers a toolset, the tools appear automatically — no separate toolset enable needed.
- If the plugin uses Mnemosyne or other optional deps, those must be installed separately.

## Updating a Plugin

Since user plugins are file-copies (not package-managed), updating means repeating the install:

```bash
cd /tmp
git clone https://github.com/user/repo.git --depth 1
cp -r repo/<plugin-dir>/* ~/.hermes/plugins/<name>/
hermes plugins enable <name>   # re-enable if needed
rm -rf /tmp/repo
```

Then `/reset` for the new version.

## Tracking in Community Manifest

After installing a new plugin, add an entry to `~/.hermes/community-manifest.json`:

```json
{
  "name": "plugin-name",
  "type": "plugin",
  "source": "https://github.com/...",
  "install_date": "YYYY-MM-DD",
  "version": "x.y.z",
  "install_method": "git clone → cp to ~/.hermes/plugins/<name>/",
  "update_command": "...",
  "post_update": "hermes plugins enable <name> (if needed) + /reset",
  "status": "active"
}
```

## CLI Reference

```bash
hermes plugins list              # Show all plugins + status
hermes plugins enable <name>     # Enable a plugin
hermes plugins disable <name>    # Disable a plugin
hermes plugins install <name>    # Install from bundled/pip (NOT community)
hermes plugins remove <name>     # Remove a plugin from registry
```

## Troubleshooting

| Symptom | Likely Cause |
|---------|-------------|
| Plugin shows "enabled" but tools don't appear | Plugin hasn't been loaded yet — needs `/reset` or new session |
| `hermes plugins enable` fails with "not found" | Plugin directory missing from `~/.hermes/plugins/<name>/` or no valid `plugin.yaml` |
| Plugin loads but hooks don't fire | `register(ctx)` function missing or didn't call `ctx.register_hook()` |
| Tools registered but model doesn't use them | Model needs to be a tool-calling model; check provider supports function calling |
\n## Auditing Community Additions\n\nRun a full inventory whenever the user asks what's been added, or when setting up a new environment. Check these locations:\n\n1. **User plugins** — `~/.hermes/plugins/*/plugin.yaml`\n2. **Bundled plugins with .git** — `find /usr/local/lib/hermes-agent/plugins -name .git -type d` (community plugins cloned directly into bundled dir)\n3. **User scripts** — `~/.hermes/scripts/`\n4. **Custom binaries** — `~/.hermes/bin/` (check `head` for bash vs ELF vs downloaded binary)\n5. **Pip packages** — `pip list | grep` for community packages (mnemosyne-memory, etc.)\n6. **Git repos under /root** — `find /root -maxdepth 4 -name .git -type d` (exclude Hermes own)\n7. **Local skills** — `hermes skills list` filtered by `local` source\n8. **Community manifest** — Check `~/.hermes/community-manifest.json` for existing entries\n\nUpdate the manifest with any findings. This is the checklist we used in the initial audit.\n\n## Pitfalls\n\n- Plugin names with hyphens in the directory name are fine, but Python module names can't have hyphens — the loader converts them to underscores internally.\n- The `plugin.yaml` hooks field is **informational** (used for listing/UI). The actual registration happens in `register(ctx)` via `ctx.register_hook()`. Both should agree.\n- User plugins override bundled plugins of the same name (last-writer-wins on name collision).\n- **Bundled-dir clones**: Community plugins may be cloned directly into `/usr/local/lib/hermes-agent/plugins/<category>/<name>/` (e.g. hermes-lcm in `context_engine/lcm/`). This creates problems: `hermes update` may overwrite them, and the git remote URL may contain embedded credentials (`https://user:***@github.com/...`). Check `cd <dir> && git remote -v` for credential exposure. Prefer `~/.hermes/plugins/<name>/` for all new community plugins.\n- Plugins cannot use `delegate_task`, `clarify`, `memory`, `send_message`, or `execute_code` — those are agent-level tools, not plugin-level.\n