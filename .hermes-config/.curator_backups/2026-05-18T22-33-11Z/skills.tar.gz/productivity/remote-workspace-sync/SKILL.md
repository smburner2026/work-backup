---
name: remote-workspace-sync
description: "Bidirectional rsync patterns for keeping a research/work directory in sync between local machine and remote VPS. Emphasizes safe (non-destructive) pulls."
version: 1.0.0
---

# Remote Workspace Sync

## Trigger
User needs to push changes from local → VPS or pull changes from VPS → local while protecting local-only files.

## Safe Pull (VPS → Local, Recommended Default)
```bash
rsync -avz root@<vps-ip>:/root/work/ /home/<user>/work/
```
- No `--delete`
- Only adds/updates files
- Never removes local-only content

## Full Mirror Push (Local → VPS)
```bash
rsync -avz --delete /home/<user>/work/ root@<vps-ip>:/root/work/
```
Use when you want exact parity (VPS becomes authoritative).

## Pitfalls
- `--delete` on pull can silently remove local work — avoid unless you have confirmed the VPS is the source of truth.
- Always run from the local machine.
- Use `-n` (dry-run) first when uncertain: `rsync -avzn ...`