---
name: personal-workspace
description: Organizing and maintaining a personal workspace for non-technical users running Hermes with mixed study, research, and custom agent workloads. Encodes simplicity-first principles and durable folder structures.
---

# Personal Workspace

## Core Principles
- Keep structure simple and flat where possible.
- Separate concerns clearly: study material, research, agents, scripts, and outputs.
- Prefer local-first testing before introducing VPS or new tools.
- Data ingestion (chat histories, external texts) goes into `archive/` first, then processed into relevant folders.

## Recommended Top-Level Structure

work/
├── dabt/                    # Domain-specific study (DABT in this case)
│   ├── references/
│   ├── deep-dives/
│   ├── notes/
│   └── practice/
├── research/                # General research and scheduled digests
│   ├── sources/
│   └── digests/
├── agents/                  # Custom agent personalities and their knowledge
│   └── [agent-name]/
│       ├── persona/
│       ├── knowledge/
│       └── outputs/
├── scripts/                 # Reusable Python utilities and tools
├── output/                  # Final compiled artifacts (PDFs, exports)
├── archive/                 # Raw imports and inactive material (Grok histories, large dumps)
└── __pycache__/             # Ignored / cleaned periodically

## Data Ingestion Workflow
1. Dump raw material (Grok exports, Substack extracts, etc.) into `archive/`.
2. Process in small chunks.
3. Move summarized or extracted content into the appropriate folder (`dabt/`, `agents/[name]/knowledge/`, etc.).
4. Save high-value user patterns via the memory tool rather than keeping raw logs.

## Style & Interaction Rules
- Default to minimal, direct responses.
- Avoid unnecessary explanations or scaffolding unless requested.
- When user says "just some thoughts" or is exploring, stay in planning mode and do not execute file changes until explicitly told to proceed.
- Never introduce new tools or complexity unless the current setup demonstrably cannot handle the task.

## Pitfalls to Avoid
- Do not scatter agent-related files across multiple top-level folders.
- Do not put raw large imports directly into active folders (`dabt/`, `agents/`).
- Resist the urge to create many narrow subfolders early; expand only when volume justifies it.

## Future Expansion
- When a VPS is added, mirror the same structure on the remote machine.
- Use `agents/` as the home for reusable personality definitions.