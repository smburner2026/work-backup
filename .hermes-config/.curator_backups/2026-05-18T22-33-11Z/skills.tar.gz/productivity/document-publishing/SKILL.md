---
name: document-publishing
description: Modify, format, and convert documents for delivery — font/size adjustments in .docx, format conversion (docx→PDF), and file delivery. For TempMoon's document workflows (Vallentin translation, e-reader publishing, etc.).
version: 1.0
author: Hermes Agent
metadata:
  hermes:
    related_skills: [shared-content-protocol, ocr-and-documents, nano-pdf]
---

# Document Publishing

Modify and convert source documents for delivery to e-readers, Discord, or archiving. Covers .docx manipulation (python-docx) and format conversion (LibreOffice).

## Prerequisites

```bash
pip install python-docx      # .docx reading/writing
apt-get install -y libreoffice-writer  # docx → PDF conversion
```

## Workflow: Modify Font Size in .docx

When the user wants a larger font for e-reader compatibility:

```python
from docx import Document
from docx.shared import Pt

doc = Document("input.docx")

# 1. Update default style
style = doc.styles['Normal']
style.font.size = Pt(14)
style.font.name = 'Garamond'  # preserve existing font if known

# 2. Update explicit run-level sizes
for p in doc.paragraphs:
    for run in p.runs:
        if run.font.size and run.font.size.pt == 11:    # body
            run.font.size = Pt(14)
        elif run.font.size and run.font.size.pt == 13:   # subhead
            run.font.size = Pt(16)
        elif run.font.size and run.font.size.pt == 10:   # small
            run.font.size = Pt(12)

doc.save("input.docx")
```

**Pitfalls**:
- Run-level sizes override style defaults — always update both.
- Headings at 13pt or 10pt need proportional scaling too.
- Always query current sizes first with a scan pass before modifying:

```python
from collections import Counter
sizes = Counter()
for p in doc.paragraphs:
    for run in p.runs:
        if run.font.size:
            sizes[run.font.size.pt] += 1
print(dict(sizes.most_common(10)))
```

## Workflow: docx → PDF

```bash
libreoffice --headless --convert-to pdf input.docx
```

Output is `input.pdf` in the same directory. Verify:

```bash
ls -lh input.pdf
```

**Pitfalls**:
- LibreOffice must be installed (`apt-get install -y libreoffice-writer`).
- Java warning (`failed to launch javaldx`) is non-fatal — ignore it.
- For large documents, set a 60s+ timeout on the terminal call.
- Output path is always the same directory as the input; use `cd` or an absolute path.

## Delivery

- Send the **original format** (.docx or .pdf) to Discord/the platform, not a text extraction.
- Use the thread-specific target format: `discord:channel_id:thread_id`.
- Tag file path with `MEDIA:/absolute/path/to/file` in the message.
