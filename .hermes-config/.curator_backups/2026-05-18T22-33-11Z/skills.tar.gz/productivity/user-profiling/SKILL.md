---
name: user-profiling
description: Ingesting and digesting external chat histories to build durable user memory and preferences.
---

# User Profiling & Memory Ingestion

Process external chat histories and user signals to build and maintain a rich, durable model of the user inside Hermes memory.

## When to use
- User provides chat exports, share links, or long conversation logs from other models.
- User wants Hermes to internalize preferences, style, recurring topics, and personal context from past interactions.
- Building or updating long-term user profile across sessions.

## Approach
1. Receive chat history (via paste, file, or link).
2. Extract high-signal facts: preferences, recurring topics, communication style, domain interests, and expectations.
3. Use `memory` tool to add/replace durable entries (keep concise, under limit) OR use `soul-compression` skill to build a Type B (User Master Persona) soul for richer representation.
4. Process in chunks for long histories.
5. Prioritize quality over quantity — focus on patterns that affect future behavior.

## Next Step: Soul Compression

After extracting traits from chat histories, consider loading the **soul-compression** skill to build a Type B (User Master Persona) soul. The workflow is:

1. User-profiling extracts raw traits and patterns from chat logs
2. Soul-compression packs those traits into a dense, structured soul (SOUL+Rubric+Loops+Guardrails)
3. The resulting soul can be further compressed to fit Hermes's USER.md memory slot (≤1,375 chars) using the USER.md Compression Pattern in that skill

This two-skill workflow produces a richer, more portable representation than memory entries alone.

## References
- See `references/grok-export-processing.md` for handling fragmented exports.
- See `references/memory-management.md` for best practices on staying under memory limits.
- See `prompt-engineering/soul-compression/SKILL.md` for the compression framework.