---
name: engineering-discipline
description: "Behavioral guidelines for rigorous, minimal, surgical coding — think first, keep it simple, touch only what's needed, verify at every step."
version: 1.0.0
author: Derived from CLAUDE.md guidelines
license: CC0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [coding-conduct, discipline, simplicity, goal-driven, surgical-changes]
    related_skills: [writing-plans, requesting-code-review, test-driven-development, systematic-debugging]
---

# Engineering Discipline

A set of behavioral guidelines for coding work, derived from the CLAUDE.md
specification. Load this skill at the start of any non-trivial coding task to
establish the operating contract before touching files.

**Tradeoff:** These guidelines bias toward caution over speed. For trivial tasks
(one-line fixes, obvious config changes), use judgment and proceed.

## The Four Principles

### 1. Think Before Coding

> Don't assume. Don't hide confusion. Surface tradeoffs.

Before implementing anything:
- **State your assumptions explicitly.** If uncertain, ask.
- **Surface multiple interpretations** — don't pick the most likely one silently.
  Present alternatives and let the user decide.
- **If a simpler approach exists**, say so. Push back when warranted.
- **If something is unclear, stop.** Name what's confusing. Ask.

**Pitfall:** The default LLM behaviour is to infer the most likely interpretation
and run with it. This rule explicitly countermands that — present options first.

### 2. Simplicity First

> Minimum code that solves the problem. Nothing speculative.

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

**Self-check:** "Would a senior engineer say this is overcomplicated?" If yes,
simplify.

### 3. Surgical Changes

> Touch only what you must. Clean up only your own mess.

When editing existing code:
- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, **mention it** — don't delete it.

When your changes create orphans:
- Remove imports/variables/functions that YOUR changes made unused.
- Do NOT remove pre-existing dead code unless asked.

**The test:** Every changed line should trace directly to the user's request.

### 4. Goal-Driven Execution

> Define success criteria. Loop until verified.

Transform tasks into verifiable goals:
- "Add validation" → "Write tests for invalid inputs, then make them pass"
- "Fix the bug" → "Write a test that reproduces it, then make it pass"
- "Refactor X" → "Ensure tests pass before and after"

For multi-step tasks, state a brief plan up front:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria let you loop independently. Weak criteria ("make it
work") require constant clarification.

## When to Load This Skill

- At the start of any non-trivial coding task (feature, refactor, bug fix)
- Before writing plans (`writing-plans` skill)
- Before delegating tasks to subagents
- Whenever user shares a specification or requirements document

**Do NOT load for:** conversation-only modes, research, reading code without
modifying it, trivial one-line changes.

## Handling Reference Documents

When the user shares a document (spec, guideline, reference) without an explicit
instruction to act on it:

- **Treat it as material for discussion**, not as a prompt to implement.
- Do NOT modify memory, write files, or take action based on it unless asked.
- If in doubt, ask: "Is this for reference, or would you like me to do something
  with it?"

## Reference Files

- `references/CLAUDE.md` — the full source document these guidelines derive from

## Verification

This skill is working if:
- Fewer unnecessary changes in diffs
- Fewer rewrites due to overcomplication
- Clarifying questions come before implementation rather than after mistakes
- Orphan cleanup is scoped to what your changes made unused
