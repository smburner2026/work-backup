---
name: book-pdf-compilation
description: Compile a series of markdown chapters or OCR text pages into a single bound PDF volume (fpdf2). Handles noise cleaning, chapter ordering, table of contents, title casing, inline formatting, and academic styling.
---

# Book PDF Compilation Skill

Compile a series of markdown chapter files into a single bound PDF volume using fpdf2 (Liberation Serif font).

## Workflow

1. **Extract chapters** from source (Substack, etc.) into individual `.md` files in `md_dir/`
2. **Define chapter order** via a `BOOK_ORDER` list (slugs matching filenames)
3. **Define section mappings** for which slugs belong to which chapter and their section numbers
4. **Create compiler script** (`compile_book.py`) and run it

## Style Preferences (user's established choices)

- **Font**: 12pt Liberation Serif (LiberationSerif-*.ttf on Ubuntu/Debian)
- **Leading**: 6.5pt
- **Margins**: 25mm
- **Body**: justified text for markdown chapters (`align='J'`); left-aligned for OCR-sourced text (`align='L'` — fpdf2's justification engine breaks on long hyphenation-free paragraphs)
- **Chapter titles**: 16pt bold centered, with a decorative rule beneath
- **Section labels on chapter pages**: 11pt italic gray
- **Subsection headings (`##`, `###`)**: rendered as bold centered (`##`) or left (`###`) rather than skipped
- **Inline formatting**: `*italic*` → italic, `**bold**` → italic (academic convention, not bold), `***bold italic***` → bold italic
- **Title case** (applied to all chapter/section titles):
  - First and last word always capitalized
  - First word after `:` , `?` , `—` , `!` , `;` always capitalized
  - Proper nouns always capitalized (Communist, Bolshevik, Soviet, Hitler, Stalin, German, Russian, European, Nazi, Fascist, etc.)
  - Minor words lowercase mid-sentence (of, the, and, in, to, from, with, against, towards, by, at, as, into, etc.)
  - ALL-CAPS preserved as-is
- **TOC**: Hierarchical — chapter headings in bold, sections indented in italic
- **Overflow protection**: single words wider than page width fall back to `multi_cell()` wrapping

## Key Implementation Details

### extract_title_from_md(md_text)
Priority order:
1. `# Heading` (multiline)
2. `**N. Section Title**` (bold with leading number)
3. `N. Section Title` (plain numbered at paragraph start)
4. `**Title**` (bold, excluding Chapter-line starts, `[bracket notes]`, Roman-numeral heads)
5. `Chapter X: Title` pattern
6. `**IV Chapter Head**` (bold Roman-numeral)
7. `IV. N. Title` (chapter.section numbering)
8. First substantive standalone line (15-150 chars, capital start, plain text)

### to_title_case(text)
Standard English title case with custom proper-noun set and after-punctuation capitalization.

## Pitfalls

- fpdf2 `cell()` does NOT wrap — any single word wider than page width must use `multi_cell()` instead
- `re.MULTILINE` is required for `^`/`$` patterns when scanning markdown body text
- `self` is not available in outer `compile_book()` function — use `pdf.w` instead of `self.w`
- Liberation Serif italic font missing `\n` glyph is a cosmetic warning, not an error
- When stripping punctuation for `to_title_case`, use `lstrip`/`rstrip` to track leading/trailing punctuation separately (avoids double-letter bug from `w[:len(w)-len(stripped)]` approach)
- **OCR-specific pitfalls and workflow**: see `references/ocr-page-compilation.md` — covers noise identification via frequency analysis, header blacklisting, line-break joining, and continuous text flow. **Critical:** three compounding fpdf2 `multi_cell` bugs (x-position drift, long-string corruption, chunk boundary artifacts) force the use of `write()` instead of `multi_cell` for any continuous text longer than ~50K characters. See the "Critical fpdf2 Pitfalls" section in that reference for symptoms and verification commands.
- **OCR sources always require 2–3 cleaning iterations** — the first pass will miss noise patterns visible only in the cleaned output. Budget for this. Each iteration: generate → inspect with PyMuPDF → add newly visible artifacts to the blacklist → regenerate.
- **Prefix-match for OCR merge artifacts** — running headers sometimes fuse with the next text line (e.g. "The Magic NameT"). Exact-match blacklisting misses these. Use `startswith(header)` plus a ≤3 char trailing tolerance to catch them.
- **Never deliver an OCR-sourced PDF without inspecting it first** — extract 5–8 sample pages, scan for residual headers, numbers, and stamps, and only report to the user once confirmed clean.
- **`align='J'` breaks on OCR text** — fpdf2's justification stretches inter-word spacing to fill the line. Without hyphenation, long paragraphs produce lines with too few words to stretch, causing the engine to break early at the same hard-break positions you just fixed. Use `align='L'` for all OCR-sourced text.
- **OCR files are physical pages, not paragraphs** — joining them with `\n\n` and splitting into paragraph blocks creates artificial breaks at page transitions. Either use section-based reconstruction (preferred, Phase A) or join all text as one continuous flow with spaces (monolithic fallback).

## DOCX Compilation (Alternative to PDF)

When the user requests a Word document (.docx) rather than a PDF — for review, editing, or track-changes — use the DOCX compilation workflow instead of the fpdf2 PDF path. See `references/docx-compilation.md` for the complete approach: explicit chapter ordering, source-file heading pattern handling, python-docx formatting (Garamond, heading hierarchy, centered headings with small caps), title page construction, and confirmed pitfalls from the Vallentin Napoleon translation project (36 chapters, ~1.1M chars).

## OCR Text Page Collections (HathiTrust / University of Michigan scans)

When the source is a ZIP or directory of numbered `.txt` files (e.g. `00000001.txt` … `00000328.txt`) rather than structured Markdown chapters, the user's preferred workflow is **section-based reconstruction** — identify structural boundaries, clean each to its own file, then compile. This is superior to the monolithic concatenation approach because it preserves section identity, makes targeted cleaning easier, and allows per-section inspection before the final compile.

### Phase A: Strip Front/Back Matter and Rebuild Sections

1. **Extract** with `python3 -m zipfile -e`, sort strictly numerically by filename.
2. **Frequency-analyze** to discover running headers (see `references/ocr-page-compilation.md` for the sampling script). Build the blacklist from data, not guessing.
3. **Delete TOC and index pages entirely** — do not attempt to clean them. TOC pages are identified by dotted leader lines (`....`), dense page-number references, or "TABLE OF CONTENTS" / "CONTENTS" headers. Index pages are identified by dense `Name, description, page_numbers` patterns. They produce more noise than value and will be rebuilt from the section structure later.
4. **Identify section boundaries** — scan through the cleaned pages and detect chapter/section headers (large text, Roman numerals, standalone bolded lines, `Chapter N` patterns). Split the corpus at these boundaries.
5. **Rebuild each section into its own `.txt` file** in an output directory (e.g. `sections/`). Name files by section number and slug (e.g. `01-preface.txt`, `02-ch1-introduction.txt`). This gives you per-section granularity for inspection and cleaning.

### Phase B: Clean and Fix Each Section File

6. For each `.txt` file: remove running headers, page numbers, library stamps, and OCR merge artifacts (prefix-match with ≤3 char trailing tolerance).
7. **Run a line-break fixing pass** — join hyphenated words across newlines, then detect and fix mid-sentence line breaks (a line ending without sentence-terminal punctuation followed by a line starting lowercase is a mid-sentence break). The text should flow naturally with paragraph breaks only at actual paragraph boundaries.
8. Scan each cleaned section file for residual noise before proceeding.

### Phase C: Compile from Clean Sections

9. Feed the cleaned per-section `.txt` files into the compiler instead of raw OCR output. Either convert to `.md` with appropriate formatting or add a plain-text body writer to the compiler script.
10. Generate the TOC from the section structure, not from OCR content.
11. Use `write(6.2, section_text)` for body text — **never `multi_cell` for continuous OCR text** (see `references/ocr-page-compilation.md` "Critical fpdf2 Pitfalls" for the three compounding bugs this avoids). For the monolithic fallback path (when section-based reconstruction isn't done), join all cleaned text with spaces and call `pdf.write(6.2, full_text)` once. `write()` is always left-aligned, which is correct for OCR-sourced books.
Always inspect the first 5–8 pages of the generated PDF **before** telling the user it's done. Extract with PyMuPDF and scan for residual noise. If clean, report the page count and path. If not, iterate the cleaner and regenerate.

See `references/mantle-of-caesar.md` for the complete reproduction recipe, header blacklist, iteration count, output statistics (328 raw pages → 185-page clean PDF), and rsync transfer pattern from the Friedrich Gundolf / Mantle of Caesar session.

See `references/ocr-page-compilation.md` for the production cleaning function, frequency-analysis snippet, and full script template.
