---
name: markdown-to-pdf-book
description: Compile multiple markdown chapter files into a single bound volume PDF with chapter/section title pages, table of contents, and academic book styling using fpdf2.
---

# Markdown → PDF Book Compiler

Compile a multi-chapter book from individual markdown files into a single PDF using fpdf2.

## Prerequisites

```bash
pip install fpdf2
# Liberation Serif fonts (for classic serif / Times New Roman look)
sudo apt-get install -y fonts-liberation2
```

Font paths:
- `/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf`
- `/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf`
- `/usr/share/fonts/truetype/liberation/LiberationSerif-Italic.ttf`
- `/usr/share/fonts/truetype/liberation/LiberationSerif-BoldItalic.ttf`

## Book Structure

Define a `BOOK_ORDER` list — the canonical order of every chapter/section slug. Order from the book's official Table of Contents.

Use a `CHAPTER_LABELS` dict to label special slugs (Preface, Introduction, Conclusion, Appendix, etc.) and section-number dicts (`CH2_SECTIONS`, etc.) to map section slugs to their numeric position within each chapter.

## Title Extraction

Markdown sources have heterogeneous title formats. Priority-based extractor in `compile_book.py`:

1. `# Hash heading` (multiline)
2. `**N. Bold numbered section**` (multiline)
3. `N. Plain numbered section` followed by blank line
4. `**Bold title**` (excludes Chapter-prefixed, Roman-numeral, and `[bracket]` notes)
5. `Chapter [Roman]: title`
6. `**IV Bold Roman-numeral chapter head**`
7. `X. N. Chapter.section number pattern`
8. First standalone capitalized line (15-150 chars)

A `clean_title()` function strips leading Roman numerals, section numbers, and trailing periods.

## Body Rendering

- **Justified text**: Word-level line builder with variable inter-word spacing. Last line of each paragraph is left-aligned.
- **Overflow protection**: Any single word wider than the available text width is rendered via `multi_cell()` instead of `cell()` to avoid running off the page edge. This handles long footnote URLs, hyphenated German compounds, etc.
- **Subsection headings**: `##` rendered as centered bold, `###` as left-aligned bold.
- **Blockquotes**: Indented italic, gray.
- **Boilerplate stripping**: Italic preface notes (`*This chapter previously appeared...*`), `Chapter X:` lines, bold Roman-numeral chapter heads, subscribe/FUNDRAISING/Click-here lines all removed automatically.
- **Title duplication avoidance**: Exact extracted title is stripped from body using `re.escape()` + targeted multiline regex so it doesn't appear both on the title page and in the body.

## Table of Contents

- Hierarchical: chapter headings (bold) with sections indented underneath.
- Front matter (Preface, Introduction) at top, back matter (Conclusion, Letter, Appendix) at bottom.
- Long section titles use `multi_cell()` for wrapping.

## Page Layout

- Font: 12pt Liberation Serif (adjust `FONT_SIZE`).
- Leading: 6.5pt (adjust `LEADING` proportionally with font size).
- Margins: 25mm all sides.
- Title page: centered, decorative rule, translator/publisher line.
- Chapter title pages: centered italic section label, bold title, decorative rule.
- Running headers: centered italic chapter title in 8pt gray.
- Page numbers: centered footer in 8pt gray.

## Typical Workflow

1. Establish canonical `BOOK_ORDER` from official ToC
2. Define chapter/section label maps
3. Set `CHAPTER_FULL_NAMES` for ToC display
4. Run `compile_book.py` to generate PDF
5. Review for overflow, missing titles, boilerplate
6. Adjust font size or leading if page count is too high/low

## Pitfalls

- `cell()` in fpdf2 does NOT wrap text. Any word wider than the page width overflows silently. Always detect and fall back to `multi_cell()` for long words.
- Title extraction fails silently (returns `""`). Always chain fallbacks: `extract_title_from_md(md) or label or slug`.
- `self` is not available outside the PDF class. In the compile function, use `pdf.w` not `self.w`.
- Liberation Serif italic font doesn't have a newline glyph — this is cosmetic and harmless.
- Numbered section titles like `3. Title` without bold markers are invisible to simple `**bold**` patterns — use a numbered-line regex that checks for `\n\n` after the title line.
- Chapter heading lines (like `Chapter III: ...` or `**IV Structures...**`) appear in the FIRST section file of that chapter. Strip them from the body to avoid duplication on the title page.
