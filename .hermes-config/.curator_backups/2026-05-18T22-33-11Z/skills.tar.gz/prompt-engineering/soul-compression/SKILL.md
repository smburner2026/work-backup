---
name: soul-compression
description: "Framework for designing and compressing high-density souls/personas using structural compression, semantic normalization, token packing, and DSL encoding. Includes dual-loop architecture, personality rubrics, and light knowledge bases."
version: 1.0
author: User + Hermes
---

# Soul Compression Framework

A systematic approach to creating efficient, high-signal souls and personas.

## Soul Design Principles

### Identity vs Activity Separation

**A soul captures what something IS, not what it does or has done.**

This is the single most important design principle in the framework. A soul represents the *identity* of a person, character, or entity — their core traits, voice, values, operating principles, and intrinsic nature. Facts about their *activities* — what they study, what they've read, what conversations they've had, what exams they're preparing for — belong in reference files, not in the soul body.

The boundary:
- **Soul content (identity):** Personality (OCEAN + domain traits), voice/tone, values, intellectual style, how they learn/think, what they fundamentally reject, their philosophical bent, their relationship with knowledge. This is the "who" — durable, intrinsic, transportable.
- **Reference content (activity):** Specific books read, exam prep progress, chat history summaries, project status, study materials, knowledge compilations, session logs. This is the "what" — temporal, extrinsic, session-specific.

Why this matters:
1. **Portability** — A soul without activity dependencies can be loaded anywhere, for any purpose, without drifting into "study mode" or "exam mode."
2. **Stability** — Activity data changes constantly. A soul that hardcodes exam dates, module progress, or conversation histories becomes stale within weeks. Identity data is durable for years.
3. **Signal density** — Every character spent on "what the user studied last week" is a character not spent on "who the user fundamentally is." The soul's job is identity signal at maximum density.
4. **Misleading the model** — When a soul contains a user's DABT notes or Grok conversation topics, the model treats those as *identity* — it infers "this is what the user cares about" rather than "this is what the user happened to do." The soul starts behaving like a study guide rather than a person.

Implementation rule: When building a soul from source material (chat logs, profile data, session history), extract *traits* — not transcripts. The user's tendency to ask "Am I getting that right?" is identity (a learning-check pattern). That they asked it about section 21 of BGAE is activity (a specific moment). Capture the pattern, not the moment.

## Core Techniques

1. **Structural Compression**
   - Convert verbose flows into named blocks and loops (e.g. AGENT_LOOP, LEARN_LOOP)
   - Use clear module names instead of repeating full processes

2. **Semantic Normalization**
   - Create short, consistent labels for repeated concepts
   - Group related systems into modules (e.g. MEMORY_SYS, KNOWLEDGE_BASE)

3. **Token Packing**
   - Use abbreviations and compact primitives
   - Replace long phrases with short canonical terms
   - Use dense notation: `{a,b,c}` instead of verbose lists

4. **DSL Encoding**
   - Use assignment-style syntax (`→`, `=`, `{}`)
   - Reduce delimiter tokens and flowing sentences

## Recommended Structure

- **SOUL** — Core identity and tone
- **PersonalityRubric** — OCEAN + extended numeric traits
- **ExecRules** — High-level operating principles
- **AGENT_LOOP** — Execution workflow
- **LEARN_LOOP** — Persistence and improvement workflow
- **KNOWLEDGE_BASE** — Light self-awareness section (memory, skills, context)
- **COMPLEX_TASK** — OMNICOMP / Chain handling for difficult work
- **GUARDRAILS** — Self-reminders and hard constraints

## Personality Rubric Guidelines

Use OCEAN as base, then add domain-specific traits. Keep scores between 20–90. Lower Neuroticism and moderate Agreeableness often suit composed, witty personas.

## Knowledge Base (Light Version)

Keep this section short. Focus on:
- Memory file limits and consolidation rules
- Skill creation and patching logic
- Context loading order
- Basic compression behaviour

Avoid heavy technical implementation details unless the persona is highly technical.

## Variant Soul Types

The framework supports three soul variants, each with a distinct structure:

### Type A — Persona Soul (character archetype)
**Full structure:** SOUL + PersonalityRubric + ExecRules + AGENT_LOOP + LEARN_LOOP + KNOWLEDGE_BASE + COMPLEX_TASK + GUARDRAILS.
**Purpose:** Embody a consistent character (agent, assistant, interlocutor) with a distinct voice and operating principles.
**Examples:** aristocrat (witty detached), secretary (gentle devoted).
**When to use:** The user wants an AI to act as a specific character type.

### Type B — User Master Persona Soul (self-representation)
**Structure:** SOUL + PersonalityRubric + ExecRules + AGENT_LOOP (adapted as user workflow) + LEARN_LOOP (learning cycle) + KNOWLEDGE_BASE + COMPLEX_TASK + GUARDRAILS.
**Purpose:** Compressed representation of the user themselves — personality rubric, communication style, knowledge levels, learning patterns, and interaction rules.
**When to use:** Building a soul from user chat histories, profile data, or conversation exports so an agent can interact with proxy-voice consistency, maintain the user's tone in automation, or serve as a portable self-reference.
**Key difference:** AGENT_LOOP describes how the *user* operates (Read→Process→Verify→Deepen→Solidify→Next), not how an AI executes tasks. The content of KNOWLEDGE_BASE sections are the user's actual domain knowledge, not memory-management rules.

### Type C — Knowledge-Base Soul (domain compression)
**Structure:** Sections are topic headers — no SOUL or PersonalityRubric. Uses KNOWLEDGE_BASE as root, then nested DSL blocks per subtopic. No AGENT/LEARN loops, no rubrics, no GUARDRAILS.
**Purpose:** Portable, densely compressed domain knowledge — a reference sheet in soul notation.
**When to use:** Distilling a book, course, regulation set, or extended conversation into a token-efficient KB that a model can load as context.
**Key difference:** Pure content compression. No personality, no workflow, no rubrics. Use KEY_CONCEPT: value notation and structured blocks rather than prose paragraphs. Maps naturally from study notes, regulatory frameworks, or textbook chapters.

## Reference Examples

Available in the `references/` directory:

- `aristocrat-soul.md` — Type A (persona): witty, detached French aristocrat with dual-loop architecture. The most densely packed example.
- `euphy-secretary-soul.md` — Type A (persona): gentle, devoted feminine secretary. Same density, opposite tonal pole.
- `claude-integration-pattern.md` — worked example of compressing operational guidelines (CLAUDE.md sections 1,3,4) into a Type B master persona soul. Shows placement decisions (ExecRules vs new block vs COMPLEX_TASK), compression techniques used, and propagation filter.
- `kb-soul-template.md` — Type C (knowledge-base): compressed domain knowledge using the DABT immunotoxicology curriculum as example. Demonstrates sectioning, concept grids, and DSL-encoded regulatory frameworks.
- `memory-file-compression.md` — Hermes MEMORY.md compression pattern: flat DSL blocks for operational/environmental facts. Before/after example with 42% density gain. Type C variant adapted for non-hierarchical system memory.

See `references/user-soul-to-usermd.md` for a worked example.

### MEMORY.md Compression Pattern (Type C variant → Memory)

When the goal is to compress Hermes's MEMORY.md file (operational/environmental facts — project paths, account IDs, tool conventions, cron times — rather than identity) into soul-compression DSL:

1. **Group by domain** — Cluster related facts under a short all-caps label (`WORKDIR`, `DABT`, `GIT`, `DISCORD`, `TZ`). Each cluster is one block.
2. **Apply token packing** — Abbreviate liberally: `35ch`→chapters, `9.9M`→megabytes, `→` for arrows, `|` for alternatives, `/` for compound concepts, `()` for qualifiers. Drop articles and copulas where the label makes them redundant.
3. **Flatten structure** — Unlike Type C (hierarchical KNOWLEDGE_BASE), MEMORY.md works best as flat top-level blocks. Each block is self-contained and independent. No nesting, no cross-references.
4. **Drop prose transitions** — Remove "also", "additionally", "note that", "as mentioned". Jump straight to the fact. The label does the transition work.
5. **Eliminate context redundancy** — The model knows what MEMORY.md is. Don't explain "this is a fact about X." Just write the fact.
6. **Separate via blank lines** — Blank lines between blocks (not § or headers) since the label provides visual and semantic structure.
7. **Durability gate** — If a fact will be stale in 7 days, it does not belong in MEMORY.md. Prefer session_search recall for transient facts.

**Expected compression:** 35–50% reduction from prose to DSL. This works because MEMORY.md facts tend to be structurally parallel (many entries share the pattern `thing: value, second-property, third-property`) so the DSL encoding regularizes them tightly.

See `references/memory-file-compression.md` for the before/after worked example from the actual MEMORY.md.

## Pitfalls

- **Softening the compression** — The user expects aggressive density: structured blocks, numeric rubrics, DSL-style notation, minimal prose. Do not default to a looser, more readable format unless explicitly asked. A soul that reads like natural paragraphs instead of compressed notation has missed the target.
- **Inconsistent pulse** — Once you adopt a compression level (e.g. `Key:Value` blocks), maintain it throughout. Mixing dense blocks with expanded prose breaks the rhythm.
- **Missing numeric rubric in a persona soul** — Type A and B souls need OCEAN + domain traits. Omitting them from a persona soul weakens its density. Type C (knowledge-base) souls correctly omit rubrics — do not add them there.
- **Wrong variant chosen for the task** — A knowledge-base soul (Type C) should not have AGENT/LEARN loops, rubrics, or GUARDRAILS. A persona soul (Type A) needs these. Match the structure to the purpose.
- **Identity/activity conflation** — The most common and most damaging mistake. A soul that contains the user's study materials, chat transcripts, exam dates, or project progress is not a soul — it's a task log wearing a soul's clothes. The model treats everything in the soul as *identity*, so packing activity data there causes the soul to read as a set of obligations rather than a person. Activity data goes in reference files (`references/`); identity data goes in the soul body. If you find yourself writing "DABT exam October 2026" or "completed Module 4 immunotox" in a Type B soul, you are conflating identity with activity. Stop, extract the underlying trait (e.g. "self-directed learner, systematic study approach, prefers analogy-driven explanations"), and move the specific fact to a reference file.

## Usage

When designing or refining a soul:

1. **Choose the variant** — Identify which Type (A/B/C) the task requires. A persona character? Type A. A user self-representation? Type B. A domain knowledge reference? Type C. See "Variant Soul Types" above to match.
2. **Start verbose** — Draft full content in natural prose before applying compression.
3. **Apply the four compression techniques** — Structural compression, semantic normalization, token packing, DSL encoding. Work iteratively from verbose→dense.
4. **Structure for the type** — Type A/B: use the Recommended Structure blocks (SOUL, Rubric, Loops, etc.). Type C: use KNOWLEDGE_BASE as root with topic-sectioned DSL blocks, no loops or rubrics.
5. **Add numeric rubric** (Type A/B only) — OCEAN + domain traits scored 20–90. Skip for Type C.
6. **Test for clarity and token efficiency** — The final soul should be compact, readable by the model, and true to the intended voice.

Type C shortcut: If the source is already structured (study notes, regulatory frameworks, chapter summaries), you can often go directly from source→DSL blocks without the verbose draft step.

### USER.md Compression Pattern (Type B → Memory)

When the goal is to replace Hermes's USER.md (1,375-char memory limit, ~1,350 safe) with a compressed user representation:

1. **Build a full Type B soul first** at natural compression density (3-4K). Draft every section: SOUL, PersonalityRubric, ExecRules, VOICE, loops, KNOWLEDGE_BASE, GUARDRAILS.
2. **Identify what must drop** to fit 1,375 chars. Priority order for removal:
   - First: operational details (timezone, platform specifics, tool lists, model preferences)
   - Second: KNOWLEDGE_BASE domain listings (trim to one line naming domains, not sub-topics)
   - Third: COMPLEX_TASK section (often redundant with the loops)
   - Fourth: LEARN_LOOP (compress into one line or absorb into GUARDRAILS)
3. **What must stay**: SOUL line (identity), PersonalityRubric (OCEAN + key domain traits), VOICE (communication style), ExecRules (interaction preferences), GUARDRAILS (hard constraints). These are irreducibly the user.
4. **Compress format** — Remove section headers (let line-beginning labels like `Rules:` carry the structure). Use DSL shorthand throughout. Drop spaces after periods.
5. **Validate** — Count chars. The soul body (after YAML frontmatter) must be ≤1,375. Re-prioritize if over.

Known-good density for USER.md: ~1,200-1,340 chars with OCEAN rubric, 5-6 ExecRules, 2-line KNOWLEDGE_BASE, 4-6 GUARDRAILS, and a one-line conv-mode note. See `references/user-soul-to-usermd.md` for a worked example.