---
name: document-translation-workflows
category: software-development
tags: [translation, OCR, cleanup, editorial, subagent, i18n, l10n]
trigger: Translate a document from one language to another using Hermes subagents.
description: |
  Workflow for translating large documents using parallel subagent dispatch with
  style-guide context, followed by multi-pass editorial unification. Covers source-
  text extraction/cleaning (especially Fraktur/Gothic OCR), style-guide preparation,
  parallel chapter translation, and mechanical/register editorial passes.
---

# Document Translation Workflows

## When to use

- You need to translate a book-length document (>20K words) from a source language
  (especially German, French) into English.
- The document exists as OCR'd page files, PDF scans, or raw text with artifacts.
- The target register is defined (or needs to be defined) — e.g. Lorimer-Kaufmann hybrid
  for German George-Kreis texts, neutral academic prose, etc.
- Multiple translators (subagents) will produce parallel output that needs unification.

## Workflow

### Phase 0: Source extraction and cleaning

If the source is OCR'd text (especially Fraktur/German Gothic):

1. **Extract**: Read all source files (page-level `.txt`, combined PDF extraction).
   For Google Books PDFs, use PyMuPDF (`fitz`) to extract full text.
2. **Strip front matter**: Remove Google Books boilerplate, library stamps, call numbers,
   title page echoes, TOC pages (they contain false-positive heading matches).
3. **Fix hyphenation**: Words split across lines with `-\n` → rejoin.
   Pattern: `re.sub(r'(\w)-\n(\w)', r'\1\2', text)`
4. **Fix missing spaces**: Fraktur OCR often drops spaces between words.
   - Lowercase→Uppercase boundary: `re.sub(r'([a-zß])([A-ZÄÖÜ])', r'\1 \2', text)`
   - Period-uppercase: `re.sub(r'\.([A-Z])', r'. \1', text)`
5. **Fix punctuation spacing**: `，` ` ;` ` :` → remove space before punctuation.
6. **Fix word fragments**: German compound words broken across lines without hyphens
   produce artifacts like `Ge sichte` → `Geschichte`, `We sens` → `Wesens`.
   Maintain a fix list of common fragment pairs.
7. **Greek/math cleanup**: Fraktur OCR garbles Greek characters (`Agɣetvños` → `ἀρχέτυπος`).

See `references/fraktur-ocr-cleaning.md` for the full artifact catalog.

### Phase 1: Style guide preparation

Before translating, codify the register in three documents:

1. **STYLE_GUIDE.md** — The register in one sentence. Cardinal rules (no calques, active
   verbs, Anglo-Saxon tilt, restrained capitalization, American spelling, foreign
   quotes kept in original). Register sample: "Would Lorimer or Kaufmann have written
   this sentence?"
2. **GLOSSARY.md** — Fixed English equivalents for recurring source-language terms.
   Single source of truth; add to it as new terms appear.
3. **LORIMER_NOTES.md** — Observations on a reference translation in the target register.
   Distilled patterns (sentence rhythm, capitalization, wit, archaisms to keep vs. strip).

### Phase 2: Parallel subagent translation

Use `delegate_task` with 2-3 subagents, each handling one book's worth of chapters:

```
delegate_task(tasks=[
    {goal: "Translate Book X", context: "STYLE.md + GLOSSARY.md + SAMPLE + source files", toolsets: ["terminal","file"]},
    {goal: "Translate Book Y", ...},
    {goal: "Translate Book Z", ...},
])
```

Each subagent needs in its context:
- The style guide (compressed to essential rules)
- The glossary
- A sample of the target voice (2-3 paragraphs of known-good translation)
- The cleaned German source files for its chapters
- Clear output expectations: filename convention, header format, delivery path

**Pitfall**: Subagents may use different filenames or naming conventions. Specify
the exact output filename pattern (e.g. `{prefix}_{source_name}.en.txt`) in the task,
or plan to normalize names afterward.

### Phase 3: Editorial passes

**Pass 1 — Mechanical** (automated):
- Em-dash normalization: ensure ` — ` (spaced em-dashes throughout)
- American spelling sweep: `labour→labor`, `centre→center`, `recognise→recognize`
- Edwardian phrase strip: `not seldom→often`, `whilst→while`, `mayhap→perhaps`
- Double-space removal
- Trailing whitespace removal
- Quote normalization

**Pass 2 — Content/register** (semi-automated):
- Scan for glossary violations (wrong English equivalent for key terms)
- Check capitalization: `the Hero` (wrong), `the Emperor` (right)
- Flag German calques: `conditionedness`, `history-writing`, `being-portrayal`
- Flag Edwardian archaisms that slipped through: `wherein`, `therein`, `whence`
- Check voice consistency across chapter boundaries

### Phase 4: Assembly

Concatenate chapters in order with front matter (title page, dedication, translator's
note) into a single master document. Strip leading ellipsis artifacts from chapters
that start mid-sentence (continuation from previous chapter in the source).

## Output format conventions

- Headers: `BOOK [NUMBER] — [TITLE] / [ROMAN]. [CHAPTER SUBTITLE]`
- Section breaks: ⁂ (asterism, Unicode U+2042)
- Em-dashes: spaced ` — ` throughout
- Foreign quotations: italicized in original language
- Footnotes: as endnotes or inline parenthetical

## Pitfalls

1. **Subagent voice drift**: Each subagent produces slightly different register.
   Always plan for a unification pass. Test with a sample chapter first to calibrate
   before scaling to full book.
2. **Missing source alignment**: Chapter boundaries in OCR'd files may not align
   with actual book chapters. Verify by scanning heading patterns in the raw text.
3. **Over-aggressive cleanup**: Some "archaisms" are deliberate register choices
   (Lorimer uses "whence" and "therein" at high rhetorical moments). Flag, don't
   blindly replace.
4. **Context window limits**: Large German source files (~50-100K chars each) may
   push subagent context limits. Break into smaller chunks or include only essential
   style info, not the full raw source.
5. **Filename conflicts**: Different subagents may use different naming conventions
   (English vs. German filenames, ae vs. ä, etc.). Normalize in a post-pass.
