# Metals & Chelation: Core Framework

## Principle 1: Metals Are Indestructible Elements

Unlike carbon-based toxicants, metals cannot be metabolized to less toxic forms. There are only three removal strategies:
1. **Enhance excretion** — chelators work here
2. **Sequester into inert forms** — metallothionein, inclusion bodies (lead–protein complexes in kidney)
3. **Stop further exposure**

This is why chelation therapy exists — it's the only active exit strategy.

## Principle 2: Entry/Exit Is Via Transporters, Not Diffusion

Metals are charged ions. They enter cells through **promiscuous ion channels and transporters**:
- Cd²⁺ rides ZIP channels (mimics Zn²⁺)
- Tl⁺ mimics K⁺
- Arsenate mimics phosphate
- Methylmercury rides amino acid transporters (binds cysteine, looks like methionine)
- Cr(VI) enters via sulfate/phosphate transporters

The body has no dedicated excretion pumps for nonessential toxic metals. Clearance is slow. Bioaccumulation is the default.

## Principle 3: Four Mechanisms of Metal Toxicity

**(a) Molecular mimicry** — metal replaces essential element at its site of action
**(b) ROS via redox cycling** — transition metals (Fe, Cu, Cr, Mn) catalyze Fenton/Haber-Weiss → hydroxyl radicals
**(c) Enzyme inhibition via sulfhydryl (–SH) binding** — As, Hg, Pb are classic –SH poisons
**(d) Aberrant gene expression** — Ni → HIF-1; As → altered DNA methylation

## HSAB (Hard-Soft Acid-Base) Framework

- **Lewis acid**: electron pair acceptor (metal cation)
- **Lewis base**: electron pair donor (ligand atom)
- **Hard acid** (Ca²⁺, Fe³⁺, Cr³⁺): small, high charge, not polarizable
- **Soft acid** (Hg²⁺, As³⁺, Cu⁺): large, low charge density, polarizable
- **Hard base** (carboxylate –COO⁻, H₂O): holds electrons tightly
- **Soft base** (thiol –SH, sulfide): holds electrons loosely, polarizable

**Rule: hard likes hard, soft likes soft.**

## Thiol (–SH) Chemistry

- Sulfur analog of alcohol's –OH
- Cysteine provides the main biological thiol
- Metals like As, Hg, Pb attack cysteine –SH in enzyme active sites = **sulfhydryl poisoning**
- Chelators with –SH groups (BAL, DMSA) outcompete biological cysteines for soft metals

## Chelator Matrix

| Chelator | Lewis base type | Route | Target metals | Key limitation |
|---|---|---|---|---|
| **BAL** (dimercaprol) | Soft (–SH ×2) | IM only | As, Hg, Au, Pb | Toxic, painful |
| **DMSA** (succimer) | Soft (–SH ×2) | Oral | **Pb** (first-line peds), As, Hg | Crosses BBB poorly |
| **EDTA** (CaNa₂EDTA) | Hard (–COO⁻, –NH₂) | IV | **Pb**, Cd | Not for Hg (mismatch); nephrotoxic |
| **Penicillamine** | Intermediate (–SH, –NH₂) | Oral | Cu (Wilson's), Pb | Autoimmune reactions |
| **DMPS** (unithiol) | Soft (–SH ×2) | IV/Oral | Hg, As, Pb | Not FDA-approved in US |
| **Deferoxamine** | Hard (hydroxamate O) | IV/IM/SC | **Fe** | Not for others |

## Critical Exception: Chromium

- **Cr(VI)** is the toxic form — enters cells easily via sulfate transporters
- **Cr(III)** is the nontoxic form — hard Lewis acid, forms octahedral complexes, kinetically trapped inside cells
- Toxicity occurs *during intracellular reduction* of Cr(VI) → Cr(III) (free radicals, DNA adducts)
- **No chelator works** — Cr(III) is already trapped. Treatment: **ascorbic acid** (accelerates extracellular reduction of Cr(VI) before cell entry)

## HSAB Limitations (When Theory ≠ Clinical Practice)

1. **Kinetic access** — can the chelator reach the metal? (brain lead, intracellular Cr(III))
2. **Timing** — is the metal still in circulation or already sequestered?
3. **Chelator toxicity** — BAL causes nephrotoxicity; EDTA chelates Ca²⁺

## Key Regulatory Threshold: Blood Lead

| Context | Threshold | Action |
|---|---|---|
| **OSHA — adult occupational maintenance** | 40 µg/dL | Maintain below |
| **OSHA — adult occupational removal** | ≥50 µg/dL | Remove from exposure |
| **CDC — pediatric level of concern** (former) | 10 µg/dL | Public health intervention |
| **CDC — pediatric reference level** (current) | 5 µg/dL | 97.5th percentile; no safe level |
| **Chelation therapy initiation** | >60 µg/dL (adults) | DMSA (peds) or EDTA/CaNa₂EDTA |

**Common trap**: confusing pediatric CDC concern levels (5–10 µg/dL) with adult OSHA occupational standards (40/50 µg/dL).
