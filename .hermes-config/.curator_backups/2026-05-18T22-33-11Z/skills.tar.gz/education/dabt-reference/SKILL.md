---
name: dabt-reference
description: "Look up toxicology concepts across extracted reference texts (Casarett & Doull 9e, Hayes 7e, regulatory guidelines). Multi-pass search: identify chapters → get passages → load full context. Returns cited passages with source, chapter, page range."
category: education
---

# DABT Reference Lookup

## Trigger

Load this skill when:
- A drill question needs a sourced explanation (the database `Explanation` column is empty)
- A deep dive needs primary source citations for a mechanism, guideline, or threshold
- Abud asks "what does Casarett say about X", "look up Y in Hayes", "find the guideline for Z"
- The phrase "→ Read: [source]" appears in drill feedback and needs expansion
- Any time you need to pull a verified passage from the reference library

Always load alongside `dabt-database` (for question context) and `dabt-drill-mode` or `dabt-deep-dive` (for session context).

## Reference Library

All extracted text lives under `/home/vthen/work/dabt-tutor/reference/extracted/`:

```
extracted/
├── casarett-doull-9e/      35 chapters,  9.9 MB — index.json
├── hayes-7e/               39 chapters, 11.0 MB — index.json
└── regulations/            29 documents, 4.2 MB — index.json
```

Each source has an `index.json` mapping chapter titles → file paths + page ranges.

For the full source PDF layout, extraction pipeline, scripts, and quirks, see `references/reference-setup.md`.

## Procedure: Three-Pass Search

### Pass 1 — Identify Candidate Files

Use `search_files` with `output_mode="files_only"` to find which chapter/regulation files mention the query:

```
search_files(
    pattern="BMD|benchmark dose",
    path="/home/vthen/work/dabt-tutor/reference/extracted",
    output_mode="files_only"
)
```

If the query is a specific chemical, use the exact name plus common variants (e.g., `"organophosphate|OP|acetylcholinesterase"`). For regulatory topics, include guideline numbers (e.g., `"ICH S2|genotoxicity testing"`).

### Pass 2 — Get Relevant Passages

Run a content search with context on the top candidate files from Pass 1:

```
search_files(
    pattern="benchmark dose",
    path="/home/vthen/work/dabt-tutor/reference/extracted/casarett-doull-9e",
    context=3
)
```

Read the matches and identify the most relevant chapter. The file names encode chapter numbers and titles — prefer chapters whose titles match the topic (e.g., `3-dose-response-a-fundamental-concept-in-toxicology.txt` for BMD questions).

### Pass 3 — Load Full Section (if needed)

If the passage snippets are too thin, open the chapter file at the right offset:

```
read_file(
    path="/home/vthen/work/dabt-tutor/reference/extracted/hayes-7e/3-dose-response...txt",
    offset=<line near the match>,
    limit=80
)
```

### Citation Format

Always cite findings as:

```
[Source] Ch.[N] "[Chapter Title]" pp.[start]-[end]
→ [1-2 sentence summary of the relevant passage]
```

Examples:
- Casarett Ch.4 "Risk Assessment" pp.146-175 → BMD is defined as...
- Hayes Ch.3 "Dose-Response" pp.125-172 → The BMD approach differs from NOAEL in that...
- ICH S2(R1) Guideline pp.1-29 → The standard battery includes...

## Source Abbreviations

| Source | Abbreviation | Chapter level |
|--------|-------------|---------------|
| Casarett & Doull's Toxicology, 9e | Casarett | 35 numbered chapters |
| Hayes' Principles and Methods, 7e | Hayes | 39 numbered chapters |
| ICH guidelines | ICH [code] | Individual documents |
| OECD test guidelines | OECD TG[#] | Individual documents |
| EPA guidelines | EPA [name] | Individual documents |
| FDA guidance | FDA [name] | Individual documents |

## Quick Topic → Chapter Mapping

For common DABT topics, these are the first files to search:

| Topic | Primary source | Chapter/file |
|-------|---------------|-------------|
| Dose-response, BMD, NOAEL | Hayes | 3-dose-response... |
| Risk assessment framework | Casarett | 4-risk-assessment |
| Mechanisms of toxicity | Casarett | 3-mechanisms-of-toxicity |
| Toxicokinetics / ADME | Casarett | 5-absorption..., 7-toxicokinetics |
| Biotransformation / metabolism | Casarett | 6-biotransformation... |
| Chemical carcinogenesis | Casarett | 8-chemical-carcinogenesis |
| Genetic toxicology | Casarett | 9-genetic-toxicology |
| Metals toxicity | Casarett | 23-toxic-effects-of-metals |
| Hayes | 19-metals |
| Pesticides | Casarett | 22-toxic-effects-of-pesticides |
| Hayes | 18-crop-protection-chemicals... |
| Solvents | Casarett | 24-toxic-effects-of-solvents-and-vapors |
| Hayes | 17-solvents-and-industrial-hygiene |
| Hepatotoxicity | Casarett | 13-toxic-responses-of-the-liver |
| Hayes | 32-hepatotoxicology |
| Nephrotoxicity | Casarett | 14-toxic-responses-of-the-kidney |
| Hayes | 33-principles-and-methods-for-renal-toxicology |
| Neurotoxicity | Casarett | 16-toxic-responses-of-the-nervous-system |
| Hayes | 35-neurotoxicology |
| Immunotoxicology | Casarett | 12-toxic-responses-of-the-immune-system |
| Hayes | 39-immunotoxicology... |
| Developmental toxicity | Casarett | 10-developmental-toxicology |
| Hayes | 38-female-reproductive... |
| Genotoxicity testing | Regulations | ich-s2r1-guideline.txt |
| Carcinogenicity testing | Regulations | ich-s1a, s1b-r1, s1cr2 |
| OECD test guidelines | Regulations | oecd/tg*.txt |
| Food safety / Redbook | Regulations | redbook*.txt |

## Pitfalls

- **Don't search the whole extracted/ tree every time** — narrow to the relevant source first (Casarett vs Hayes vs regs) unless the topic spans multiple sources
- **Chapter titles are in the filenames** — use them to gauge relevance before reading
- **Page numbers**: search_files returns file line numbers, not book pages. Scan the text for embedded printed page markers (standalone numbers like "1124" on their own line, often followed by "Toxic Agents" or chapter headers) to report accurate pagination. Never cite extraction line numbers as pp. values.
- **Page numbers: use the extraction header, not internal markers.** Every extraction file begins with a header block including `# Pages: X-Y` — this is the authoritative PDF pagination for the chapter. Internal page markers (standalone numbers on their own lines like `1124`) are printed book page numbers, which may differ from PDF pages. When the user asks for page numbers, always cite from the header, never from line numbers or internal markers. If the header and internal markers disagree, cite the header range and note the offset.
- **Regulations don't have TOC** — they're single documents, so Pass 2 (content search with context) is usually sufficient
- **If a search returns nothing**, the topic may use different terminology. Try synonyms (e.g., "benchmark dose" ↔ "BMD", "uncertainty factor" ↔ "UF" ↔ "safety factor")
- **The index.json files are your best friend** — read them first if you need an overview of available chapters
