# DABT Exam Blueprint — 2026 ABT Candidate Handbook

## Domain I. Conduct of Toxicological Studies — 36%
- **A. Design** — 11%
  - Study design principles, GLP, OECD Test Guidelines, ICH S-series
  - Dose selection, route of administration, species/strain selection
  - Sample size, power analysis, statistical considerations
- **B. Execute** — 9%
  - Study execution, data collection, quality assurance
  - Histopathology, clinical pathology, necropsy
  - Good Laboratory Practice (GLP) compliance
- **C. Interpret** — 16% *(largest single sub-domain on exam)*
  - Data interpretation, adversity determination
  - NOAEL/LOAEL identification, statistical analysis
  - Pathology interpretation, weight-of-evidence

## Domain II. Mechanistic Toxicology — 13%
- Hypothesis development and testing
- Species differences in toxic response
- Susceptibility factors (genetic, age, sex, health status)
- MOA/AOP (Mode of Action / Adverse Outcome Pathway)
- Direct vs indirect action
- Translation across biological levels (in vitro → in vivo → human)
- Application to risk assessment
- Disease and genetic models

## Domain III. Risk Assessment — 38%
- **A. Hazard Identification** — 12%
  - Weight of evidence, cancer classification (EPA, IARC)
  - Epidemiology, structure-activity relationships
- **B. Exposure Assessment** — 8%
  - Biomonitoring, exposure reconstruction
  - Occupational, environmental, consumer exposure
- **C. Dose-Response Assessment** — 9%
  - Dose-response modeling, BMD (Benchmark Dose)
  - NOAEL/LOAEL, POD (Point of Departure) selection
  - Uncertainty factors (UF), modifying factors (MF)
- **D. Risk Characterization & Management** — 9%
  - Margin of Exposure (MOE), risk characterization
  - Risk management, risk communication

## Domain IV. Applied Toxicology — 13%
- Ecotoxicology and environmental toxicology
- Public health response and emergency management
- Ecosystem-driven exposures
- Exposure reconstruction
- Biomonitoring programs
- Susceptible subpopulations (children, elderly, pregnant women)
- Sustainable product development / green chemistry

## Drill Set Targeting
- **5-question set**: ~2 Risk Assessment, ~2 Conduct of Studies, ~1 Mechanistic or Applied
- **20-question diagnostic**: ~7–8 RA, ~7 Conduct of Studies, ~3 Mechanistic, ~3 Applied
- Within RA and Conduct, distribute by sub-domain weight
- Track and report performance at sub-domain granularity

## Primary References
- Casarett & Doull's Toxicology (chapter-level citations for gap remediation)
- 2026 ABT Candidate Handbook (canonical blueprint)
- EPA Cancer Guidelines (2005)
- EPA BMD Technical Guidance
- ICH S-series guidelines
- OECD Test Guidelines

## Question Database
- File: `reference/Claude_import/DABT_Practice_Questions_Database.xlsx`
- Sheet: "Questions"
- 446 questions from Mini-ABT Exams 1–11 (official ABT practice exams)
- Fields: ID, Source Exam, Question #, Question, A–H, Correct Answer, Correct Answer Text, Explanation, Topic (Primary), All Topics, Source File
- Topics include: Metals, Solvents, Pesticides, Carcinogenesis, Liver/Kidney/Lung toxicity, Neurotoxicity, Immunotoxicity, Endocrine, Reproductive, General Toxicology, Mechanisms, ADME, etc.
