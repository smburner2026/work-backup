---
name: dabt-database
description: "Query the DABT Practice Questions Database (446 questions, Mini-ABT Exams 1-11) — pandas-based selection, topic filtering, blueprint-weighted sampling, anti-clustering, dedup tracking."
category: education
---

# DABT Practice Questions Database

## Database Location

```
DB_PATH = '/home/vthen/work/dabt-tutor/reference/data/DABT_Practice_Questions_Database.xlsx'
```

**NOTE:** The database file is confirmed at this path (165 KB). If missing or corrupted, check for backup ZIPs under `reference/`. The companion classification CSV is at `reference/data/question_classifications.csv`.

Sheet: `Questions` (must be specified explicitly as `sheet_name='Questions'` in `pd.read_excel()`)

## Column Map

| Column | Type | Description |
|--------|------|-------------|
| `ID` | string | Unique question ID (DABT-0001 to DABT-0446) |
| `Source Exam` | int | Mini-ABT Exam number (1-11) |
| `Question #` | int | Question number within the source exam |
| `Question` | string | Full vignette text |
| `A` through `H` | string | Answer options |
| `Correct Answer` | string | Letter of correct answer (A-H) |
| `Correct Answer Text` | string | Full text of the correct answer |
| `Explanation` | string | Currently empty in database |
| `Topic (Primary)` | string | Primary topic tag |
| `All Topics` | string | Semicolon-separated list of all topic tags |
| `Source File` | string | Source filename reference |

## Topic Map (Primary → Domain)

Inferred from question content and topic. Used until Phase 3 pre-tagging is complete.

```
Domain I (Conduct of Studies):
  - General Principles & Concepts
  - General Toxicology
  - Toxicokinetics / ADME
  - Biotransformation / Metabolism

Domain II (Mechanistic Toxicology):
  - Mechanisms of Toxicity
  - Carcinogenesis & Mutagenesis
  - Genotoxicity / DNA Damage

Domain III (Risk Assessment):
  - Risk Assessment & Regulatory

Domain IV (Applied Toxicology):
  - Metals & Metalloids
  - Solvents & Hydrocarbons
  - Pesticides – Insecticides
  - Pesticides – Herbicides
  - Pesticides – Rodenticides
  - Pesticides – Fumigants
  - Gases – Asphyxiants & Irritants
  - Air Pollution & Particulates
  - Drugs & Therapeutics – Toxicology
  - Plant Toxins
  - Animal & Microbial Venoms / Toxins
  - Mycotoxins
  - Food Additives, Cosmetics & GRAS
  - Alcohols & Methanol/Ethanol
  - Radiation / UV / Ionizing

Cross-cutting (Organ System):
  - Liver / Hepatotoxicity
  - Kidney / Nephrotoxicity
  - Lung / Pulmonary Toxicity
  - Nervous System / Neurotoxicity
  - Skin / Dermatotoxicity
  - Eye / Ocular Toxicity
  - Cardiovascular Toxicity
  - Hematology & Blood Toxicity
  - Immunotoxicology / Allergy
  - Endocrine Toxicology
  - Reproductive & Developmental Toxicity
```

Note: This is a rough mapping. Organ system topics cross-cut all domains. Refine as needed.

## Classification Companion File

A pre-tagged companion CSV exists at:
```
reference/data/question_classifications.csv
```

Joins on `ID`. Contains: Domain, Sub-Domain, Task, Bloom Level, Domain Confidence, Bloom Confidence.

**IMPORTANT — Domain column values:** The `Domain` column uses short names: `"Domain I"`, `"Domain II"`, `"Domain III"`, `"Domain IV"` — NOT the full descriptive names (e.g., `"Domain I: Conduct of Studies"`). Filter on the short name:

```python
ra_pool = df[df['Domain'] == 'Domain III']
conduct_pool = df[df['Domain'] == 'Domain I']
# NOT: df[df['Domain'] == 'Domain III: Risk Assessment']
```

The `Sub-Domain` column uses abbreviated values: `"Applied"` (Domain IV), `"C.Interpret"` (Domain I), `"Mechanistic"` (Domain II), `"D.RiskChar&Mgmt"` (Domain III), `"B.Execute"` (Domain I), `"A.Design"` (Domain I).

**Bloom Level** distribution (446 questions): Apply (224), Remember/Understand (219), Analyze (3). The Analyze pool is tiny — treat a question classified Analyze as a rare event.

Load alongside the main database:
```python
cls = pd.read_csv('/home/vthen/work/dabt-tutor/reference/data/question_classifications.csv')
df = df.merge(cls[['ID', 'Domain', 'Sub-Domain', 'Task', 'Bloom Level']], on='ID', how='left')
```

Confidence levels: 'high' (topic mapping), 'medium' (reasonable inference), 'low' (keyword-based override, needs human review).

Full classification methodology, known limitations, topic-to-domain mapping table, and refinement strategy: see `references/classification-methodology.md`.

**Domain distribution snapshot:** `references/classification-distribution.md` — counts by Domain, Sub-Domain, and Bloom Level (computed from the classification CSV). Useful for planning sampling strategy without re-querying.

## Query Patterns

### Load the Database

```python
import pandas as pd

DB_PATH = '/home/vthen/work/dabt-tutor/reference/data/DABT_Practice_Questions_Database.xlsx'
df = pd.read_excel(DB_PATH, sheet_name='Questions')
```

### Filter by Topic

```python
topic_df = df[df['Topic (Primary)'] == 'Metals & Metalloids']
# Or broader match on All Topics:
topic_df = df[df['All Topics'].str.contains('Metals', na=False)]
```

### Blueprint-Weighted Sampling

For a mixed 5-question set, sample by domain proportions:
- Risk Assessment: 38% = ~2 questions
- Conduct of Studies: 36% = ~2 questions
- Mechanistic Toxicology: 13% = ~1 question or 0
- Applied Toxicology: 13% = ~1 question or 0

Rotate which domain gets the odd question across sets to maintain overall proportions.

```python
# Example: sample 2 from RA, 2 from Conduct, 1 from Mech+Applied (alternate)
ra_topics = ['Risk Assessment & Regulatory']
conduct_topics = ['General Principles & Concepts', 'General Toxicology', 'Toxicokinetics / ADME']
mech_topics = ['Mechanisms of Toxicity', 'Carcinogenesis & Mutagenesis', 'Genotoxicity / DNA Damage']
applied_topics = ['Metals & Metalloids', 'Solvents & Hydrocarbons', 'Pesticides – Insecticides', ...]

ra_pool = df[df['Topic (Primary)'].isin(ra_topics)]
conduct_pool = df[df['Topic (Primary)'].isin(conduct_topics)]
mech_pool = df[df['Topic (Primary)'].isin(mech_topics)]
applied_pool = df[df['Topic (Primary)'].isin(applied_topics)]

# Sample with dedup
import json, random
state = json.load(open('/home/vthen/work/dabt-tutor/progress/state.json'))
asked = set(state.get('asked_question_ids', []))

def sample_n(pool, n, asked, source_used, max_per_source=1):
    """Sample n questions, avoiding asked IDs and clustering from same source exam."""
    available = pool[~pool['ID'].isin(asked)]
    if available.empty:
        return available.sample(0)
    # Avoid clustering: don't pick from same Source Exam already used in this set
    available = available[~available['Source Exam'].isin(source_used)]
    if len(available) < n:
        # Fall back: allow some clustering
        available = pool[~pool['ID'].isin(asked)]
    selected = available.sample(min(n, len(available)), random_state=random.randint(0, 10000))
    return selected

# Track source exams used in this set
source_used = set()
questions = []
for pool, n in [(ra_pool, 2), (conduct_pool, 2), (other_pool, 1)]:
    sampled = sample_n(pool, n, asked, source_used)
    source_used.update(sampled['Source Exam'].values)
    questions.append(sampled)
set_df = pd.concat(questions)
```

### Dedup Tracking

After each set, append asked IDs to state.json:

```python
state['asked_question_ids'].extend(set_df['ID'].tolist())
json.dump(state, open('/home/vthen/work/dabt-tutor/progress/state.json', 'w'), indent=2)
```

When `asked_question_ids` reaches ~400, notify Abud that the question pool needs rotation or reset.

### Anti-Clustering

Never pull 2+ questions from the same `Source Exam` in a single 5-question set. Track `Source Exam` values used in the current set and exclude them from subsequent draws.

## Source Exams

| Exam | Questions | Type |
|------|-----------|------|
| Mini-ABT 1 | 40 | Practice |
| Mini-ABT 2 | 40 | Practice |
| Mini-ABT 3 | 40 | Practice |
| Mini-ABT 4 | 40 | Practice |
| Mini-ABT 5 | 41 | Practice |
| Mini-ABT 6 | 40 | Practice |
| Mini-ABT 7 | 40 | Practice |
| Mini-ABT 8 | 40 | Practice |
| Mini-ABT 9 | 40 | Practice |
| Mini-ABT 10 | 40 | Practice |
| Mini-ABT 11 | 45 | Practice |
| **Total** | **446** | |

## Pitfalls

- Must specify `sheet_name='Questions'` — just `pd.read_excel(path)` returns the first sheet which may be wrong
- `Explanation` column is empty — all explanations must be reasoned from primary references. Use `dabt-reference` skill to look up mechanisms, thresholds, and regulatory details from Casarett, Hayes, and guideline documents.
- `Correct Answer` is the letter (A-H), `Correct Answer Text` is the full text
- Topic names include em-dashes (—) and en-dashes (–) — match exactly
- Some questions have up to H (8 options), most have A-E
- `All Topics` field is semicolon-separated — use `str.contains()` with `na=False`
- Organ system topics (Liver, Kidney, etc.) cross-cut all four domains — classify by the primary clinical context of the question
- `Domain` column values are short names (`"Domain I"`, not `"Domain I: Conduct of Studies"`) — see Classification Companion File section for exact values
