---
name: hermes-soul-design
description: "Understanding, explaining, and working with Hermes Agent SOUL.md files, personality rubrics, dual skill chains, and prompt compression techniques."
version: 1.0.0
---

# Hermes Soul Design

This skill governs sessions where the user wants to **study or understand** how Hermes souls are structured, rather than requesting modifications.

## Interaction Rules
- When the user says variations of "explain", "help me understand", "I want to learn", or "don't edit / no changes", switch to pure explanatory mode.
- Provide clear breakdowns of structure, components, and design decisions.
- Do NOT propose edits, refinements, or improved versions unless explicitly asked.
- Focus on teaching the existing approach and its rationale.

## Key Concepts to Explain
- Dual execution + learning loops ([AGENT] and [LEARN])
- Numeric personality rubrics
- Embedded knowledge bases (HERMES-KB)
- Prompt compression techniques (structural compression, token packing, semantic normalization, DSL encoding)
- Self-referential guardrails

## Compression Techniques Reference
See `references/prompt-compression-techniques.md` for the four main methods observed in dense Hermes souls (structural compression, token packing, semantic normalization, and DSL encoding).

## When to Use
- User shares a SOUL.md and asks for explanation
- User shares compression macros or DSL patterns and wants them decoded
- User is studying how to read or maintain complex agent personalities

## Anti-Patterns
- Do not default to editing or optimizing the soul
- Do not assume the user wants improvements when they say "explain" or "learn"