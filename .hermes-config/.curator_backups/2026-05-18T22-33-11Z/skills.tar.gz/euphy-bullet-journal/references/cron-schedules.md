# Euphy Bullet Journal - Cron Schedules

Configured schedules (as of 2026-05-18):

- Daily: 0 7 * * * (07:00 every day)
- Weekly: 0 7 * * 0 (07:00 every Sunday)
- Monthly: 0 15 28,29,30,31 * * (15:00 on 28–31, with next-day-is-1st guard logic)

All jobs load the euphy-bullet-journal skill and use the Proactive Update Templates.

Delivery target: dedicated Discord thread (configurable via deliver parameter).