---
name: wsl-drive-cleanup
description: "Systematic walkthrough and safe cleanup of mounted Windows C: drive from WSL. Identifies redundant installs, stale temp folders, legacy remnants, and junk without touching system-critical files. Encodes observed deletion patterns for Intel, Steam duplicates, ControlD, adobeTemp and similar."
category: devops
---

# WSL C: Drive Cleanup

## Trigger
User requests review of C: drive for useless or deletable files/folders while in WSL.

## Workflow
1. Begin with top-level listing: ls -la /mnt/c/
2. Size suspicious folders with du -sh (ignore E-size artifacts on AppData, OneDrive, Videos caused by reparse points and cloud placeholders).
3. Inspect /mnt/c/Users/vthen/ for Downloads, Games, old Dropbox/OneDrive copies.
4. Validate primary locations:
   - Steam primary is always /mnt/c/Program Files (x86)/Steam when present.
   - Games/Steam (1.2 GB) is redundant secondary copy — delete after confirmation.
5. Safe zero-risk deletes (always verify via web_search first):
   - /mnt/c/adobeTemp/* (2019-2020 .tmp folders)
   - /mnt/c/DumpStack.log.tmp
   - /mnt/c/OneDriveTemp/*
   - /mnt/c/ProgramFilesFolder (empty)
   - /mnt/c/Intel (ExtremeGraphics 2020 remnants + empty GfxCPLBatchFiles)
   - /mnt/c/WindowsInstallationAssistant (post-update remnant)
   - /mnt/c/Users/vthen/.openjfx (151 MB JavaFX native DLL cache — safe to delete)
6. Conditional (research first):
   - ControlD: keep only if actively using Control D DNS (ctrld.exe + toml).
   - $SysReset / $GetCurrent: delete only after verifying no pending Windows reset.
   - BCUninstaller: keep if user uses bulk uninstaller; otherwise remove.
   - Dell: remove only if not using Dell hardware features.
   - NordUpdater/NordVPN: remove only if VPN is uninstalled.
7. High-risk / never touch without strong justification:
   - Anything under /mnt/c/Windows/ (LastGood.Tmp is 502 MB recovery snapshot — do not delete)
   - pagefile.sys, hiberfil.sys, swapfile.sys, $Recycle.Bin, System Volume Information, Recovery, RUXIM
8. After cleaning Program Files, optionally run the installed DeleteEmptyFolders tool (review mode first) on both Program Files and Program Files (x86).

## Mandatory Rule
Before recommending deletion of any non-obvious folder, run web_search on its name + "Program Files" or "safe to delete". Encode findings in the decision.

## Pitfalls
- du produces nonsensical sizes on junction-heavy or OneDrive folders; rely on ls and presence of executables (steam.exe, ctrld.exe).
- WSL has limited visibility into protected AppData subfolders; recommend native Disk Cleanup for deep caches.
- LastGood.Tmp under Windows looks large but is a recovery snapshot — never delete.
- RUXIM is official Microsoft Windows Update component; do not remove.

## References
references/session-2026-05-16-c-drive-walkthrough.md contains the exact folder decisions and sizes from the initiating session.